import React from 'react';
import ArticleIcon from '@mui/icons-material/Article';
import AutoAwesomeMotionIcon from '@mui/icons-material/AutoAwesomeMotion';
import PersonIcon from '@mui/icons-material/Person';
import TokenIcon from '@mui/icons-material/Token';
import makeStyles from '@mui/styles/makeStyles';
import { Provider } from 'mobx-react';
import { HashRouter, Navigate, Route, Routes } from 'react-router-dom';
import { ApiAlert } from '@/components/molecules';
import { ErrorBoundary } from 'react-error-boundary';
import ErrorFallback from '@/pages/error/ErrorFallback';
import HorizontalBar from '@/components/organisms/navigationBar/HorizontalBar';
import VerticalBar from '@/components/organisms/navigationBar/VerticalBar';
import Error from '@/pages/error';
import Login from '@/pages/login';
import Meta from '@/pages/meta/metaManagement';
import Node from '@/pages/node/nodeManagement';
import Prominer from '@/pages/prominer/dependency';
import User from '@/pages/user/userManagement';
import * as store from '@/stores';

const useStyles = makeStyles(() => ({
  root: {
    display: 'flex',
    flexDirection: 'column',
  },
}));

const App = () => {
  const classes = useStyles();
  const isLoggedIn = window.sessionStorage.getItem('session') !== null;

  return (
    <Provider {...store}>
      <ErrorBoundary FallbackComponent={ErrorFallback}>
        <HashRouter>
          <ApiAlert />
          <VerticalBar menus={menus} isLoggedIn={isLoggedIn} />
          <div className={classes.root}>
            <HorizontalBar types={types} isLoggedIn={isLoggedIn} />
            <Routes>
              <Route path="/login" element={<Login />} />
              <Route
                path="/development/user/*"
                element={<User subMenus={menus[0].subMenus} />}
              />
              <Route
                path="/development/meta/*"
                element={<Meta subMenus={menus[1].subMenus} />}
              />
              <Route
                path="/development/node/*"
                element={<Node subMenus={menus[2].subMenus} />}
              />
              <Route
                path="/development/prominer/*"
                element={<Prominer subMenus={menus[3].subMenus} />}
              />
              <Route
                path="/development"
                element={<Navigate to="/development/node/management" />}
              />
              <Route
                path="/"
                element={<Navigate to="/development/node/management" />}
              />
              <Route path="/*" element={<Error />} />
            </Routes>
          </div>
        </HashRouter>
      </ErrorBoundary>
    </Provider>
  );
};

const menus = [
  {
    title: 'User',
    icon: PersonIcon,
    subMenus: [
      { title: 'User Management', to: '/development/user/management' },
    ],
  },
  {
    title: 'Meta',
    icon: AutoAwesomeMotionIcon,
    subMenus: [
      { title: 'Meta Management', to: '/development/meta/management' },
    ],
  },
  {
    title: 'Node',
    icon: TokenIcon,
    subMenus: [
      { title: 'Node Management', to: '/development/node/management' },
    ],
  },
  {
    title: 'Prominer',
    icon: ArticleIcon,
    subMenus: [{ title: 'Dependency', to: '/development/prominer/dependency' }],
  },
];

const types = [{ title: 'Development', to: '/development/node/management' }];

export default App;
