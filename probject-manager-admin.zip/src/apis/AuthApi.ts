import axios from 'axios';
import { loginType } from '@/types/typeBundle';

const { NODE_ENV, REACT_APP_BACKEND_URL } = process.env as {
  [key: string]: string;
};
const BASE_URL =
  NODE_ENV === 'development' ? REACT_APP_BACKEND_URL : '/proobject-devserver';

const AuthApi = {
  login: async (submitValue: loginType) => {
    try {
      const { data } = await axios.post(BASE_URL + '/userInfoCheckService', {
        ...submitValue,
        withCredentials: true,
      });
      return data;
    } catch (error) {
      return error;
    }
  },
};

export default AuthApi;
