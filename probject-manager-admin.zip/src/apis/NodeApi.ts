import axios from 'axios';
import { nodesType } from '@/types/typeBundle';

const { NODE_ENV, REACT_APP_BACKEND_URL } = process.env as {
  [key: string]: string;
};
const BASE_URL =
  NODE_ENV === 'development' ? REACT_APP_BACKEND_URL : '/proobject-devserver';

const NodeApi = {
  get: async (nodeType: string) => {
    try {
      const { data } = await axios.post(BASE_URL + '/nodeList', {
        nodeType: nodeType,
      });
      return data;
    } catch (error) {
      return error;
    }
  },

  add: async (submitValue: nodesType) => {
    try {
      return await axios.post(BASE_URL + '/nodeCreate', submitValue);
    } catch (error) {
      return error;
    }
  },

  edit: async (submitValue: nodesType) => {
    try {
      return await axios.post(BASE_URL + '/nodeUpdate', submitValue);
    } catch (error) {
      return error;
    }
  },

  delete: async (
    submitValue: { serverHostName: string; nodeName: string }[]
  ) => {
    try {
      return await axios.post(BASE_URL + '/nodeDelete', {
        poDeployNodeDTOArray: submitValue,
      });
    } catch (error) {
      return error;
    }
  },
};

export default NodeApi;
