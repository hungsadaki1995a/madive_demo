import axios from 'axios';
import { userType } from '@/types/typeBundle';

const { NODE_ENV, REACT_APP_BACKEND_URL } = process.env as {
  [key: string]: string;
};
const BASE_URL =
  NODE_ENV === 'development' ? REACT_APP_BACKEND_URL : '/proobject-devserver';

const UserApi = {
  get: async (path: string) => {
    try {
      const { data } = await axios.post(BASE_URL + path, { userDiv: '' });
      return data;
    } catch (error: any) {
      return error;
    }
  },

  add: async (submitValue: userType) => {
    try {
      return await axios.post(BASE_URL + '/userCreate', submitValue);
    } catch (error) {
      return error;
    }
  },

  edit: async (submitValue: userType) => {
    try {
      return await axios.post(BASE_URL + '/userUpdate', submitValue);
    } catch (error) {
      return error;
    }
  },

  delete: async (submitValue: { userId: string; userPasswd: string }[]) => {
    try {
      return await axios.post(BASE_URL + '/userDelete', {
        userInfoDTOArray: submitValue,
      });
    } catch (error) {
      return error;
    }
  },
};

export default UserApi;
