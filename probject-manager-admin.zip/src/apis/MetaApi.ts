import axios from 'axios';
import { metaType } from '@/types/typeBundle';

const { NODE_ENV, REACT_APP_BACKEND_URL } = process.env as {
  [key: string]: string;
};
const BASE_URL =
  NODE_ENV === 'development' ? REACT_APP_BACKEND_URL : '/proobject-devserver';

interface metaGetType {
  page: number;
  pageRowNum: number;
  physicalName?: string;
  logicalName?: string;
  startWith?: string;
  contains?: string;
}

const MetaApi = {
  get: async (path: string, body: metaGetType) => {
    try {
      const { data } = await axios.post(BASE_URL + path, body);
      return data;
    } catch (error) {
      return error;
    }
  },

  add: async (submitValue: metaType) => {
    try {
      return await axios.post(BASE_URL + '/metaCreate', submitValue);
    } catch (error) {
      return error;
    }
  },

  edit: async (submitValue: metaType) => {
    try {
      return await axios.post(BASE_URL + '/metaUpdate', submitValue);
    } catch (error) {
      return error;
    }
  },

  delete: async (submitValue: { metaId: string }[]) => {
    try {
      return await axios.post(BASE_URL + '/metaDelete', {
        metaInfoDTOArray: submitValue,
      });
    } catch (error) {
      return error;
    }
  },
};

export default MetaApi;
