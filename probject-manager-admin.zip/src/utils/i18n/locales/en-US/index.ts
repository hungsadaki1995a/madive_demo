import page from './page.json';

export default {
  page,
};
