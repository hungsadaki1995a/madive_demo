export interface subMenusType {
  title: string;
  to: string;
}

export interface menusType {
  title: string;
  icon: any;
  subMenus: subMenusType[];
}

export interface loginType {
  userId: string;
  userPasswd: string;
}

export interface authType {
  email: string;
  userId: string;
  userName: string;
  userPasswd: string;
  userDiv: string;
  telNo: string;
}

export interface userType {
  accessDate?: string;
  deptCode?: string;
  description?: string;
  email: string;
  fromDate?: string;
  mobilePhone?: string;
  notAtWork?: string;
  teamLeader?: string;
  telNo: string;
  toDate?: string;
  userDiv: string;
  userId: string;
  userName: string;
  userPasswd: string;
}

export interface userSelectionType {
  selection: JSX.Element;
  email: string;
  telNo: string;
  userDiv: string;
  userId: string;
  userName: string;
  userPasswd: string;
}

export interface nodesType {
  description: string;
  nodeKey: string;
  nodeType: string;
  nodeName: string;
  nodeIp: string;
  nodeBasePort: string;
  nodeHttpPort: string;
  masterNodeKey: string;
  nodeIsSsl: string | boolean;
  serverHostName: string;
}

export interface nodesSelectionType {
  selection: JSX.Element;
  description: string;
  nodeKey: string;
  nodeType: string;
  nodeName: string;
  nodeIp: string;
  nodeBasePort: string;
  nodeHttpPort: string;
  masterNodeKey: string;
  nodeIsSsl: string | boolean;
  serverHostName: string;
}

export type selectedType = 'ALL' | 'TEST' | 'RUNTIME' | 'MASTER';

export interface metaType {
  columnName: string;
  comments: string;
  decimalSize: string;
  defaultValue: string;
  encrypt: string;
  fieldType: string;
  isKey: string;
  length: string;
  logicalName: string;
  masking: string;
  maskingRange: string;
  metaId: string;
  metaType: string;
  physicalName: string;
  schemaName?: string;
  tableName: string;
  updateTime?: string;
}

export interface metaSelectionType {
  selection: JSX.Element;
  physicalName: string;
  logicalName: string;
  comments: string;
  fieldType: string;
  length: string;
  metaType: string;
}

export interface paginationType {
  page: number;
  pageSize: number;
  totalCount: number;
}

export interface dependencyType {
  gitUrl: string;
  name: string;
  gitToken: string;
  gitPlatformType: string;
  gitBranch: string;
}

export interface dependencyResponseType {
  createdAt: string;
  id: number;
  projects: { id: number; name: string }[];
  repository: {
    branchName: string;
    lastCommitId: string;
    name: string;
    platform: { type: string; url: string };
    token: string;
    url: string;
  };
}

export interface resourceResponseType {
  id: number;
  name: string;
  packageName: string;
  path: string;
  project: { id: number; name: string };
  type: string;
}

export interface dependencySettingsType {
  project: number | '';
  type: string;
  direction: string;
  name: string;
}

export interface apiAlertType {
  severity: 'success' | 'error' | null;
  message: string | null;
}
