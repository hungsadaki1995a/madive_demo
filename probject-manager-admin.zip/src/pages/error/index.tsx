import makeStyles from '@mui/styles/makeStyles';
import { Link } from '@mui/material';
import ErrorOutlineIcon from '@mui/icons-material/ErrorOutline';

const useStyles = makeStyles(() => ({
  wrap: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'column',
    height: 650,
  },
  icon: {
    width: 200,
    height: 200,
    color: '#5E82E0',
  },
  message: {
    margin: 25,
    fontSize: 24,
    fontWeight: 700,
  },
  description: {
    textAlign: 'center',
  },
  links: {
    display: 'flex',
    flexDirection: 'column',
    marginTop: 15,
  },
}));

const Error = () => {
  const classes = useStyles();

  return (
    <div className={classes.wrap}>
      <ErrorOutlineIcon className={classes.icon} />
      <div className={classes.message}>Page Not Found</div>
      <div className={classes.description}>
        The page you are looking for does not exist.
        <br></br>
        Here are some helpful links instead:
      </div>
      <div className={classes.links}>
        <Link href="/development/user/management">User Management</Link>
        <Link href="/development/meta/management">Meta Management</Link>
        <Link href="/development/node/management">Node Management</Link>
        <Link href="/development/prominer/dependency">Dependency</Link>
      </div>
    </div>
  );
};

export default Error;
