import { Routes, Route, Navigate } from 'react-router-dom';
import UserManagement from '@/pages/user/userManagement/UserManagement';
import { subMenusType } from '@/types/typeBundle';
import Error from '@/pages/error';

const User = ({ subMenus }: { subMenus: subMenusType[] }) => {
  return (
    <Routes>
      <Route
        path="/management"
        element={<UserManagement title={subMenus[0].title} />}
      />
      <Route
        path="/"
        element={<Navigate to="/development/user/management" />}
      />
      <Route path="/*" element={<Error />} />
    </Routes>
  );
};

export default User;
