import { useRef, Dispatch, SetStateAction } from 'react';
import { observer } from 'mobx-react';
import { Select, SelectChangeEvent, MenuItem, IconButton } from '@mui/material';
import makeStyles from '@mui/styles/makeStyles';
import { useStore } from '@/utils';
import UserManagementHeaderDialog from './UserManagementHeaderDialog';
import AddIcon from '@mui/icons-material/Add';
import SearchIcon from '@mui/icons-material/Search';
import { userType } from '@/types/typeBundle';

const useStyles = makeStyles(() => ({
  create: {
    display: 'flex',
    alignItems: 'center',
    border: '1px solid #0175bc',
    padding: 5,
    color: '#0175bc',
    fontSize: 14,
    cursor: 'pointer',
    '& svg': {
      color: '#0175bc',
    },
  },
  select: {
    paddingLeft: 12,
    width: 175,
    fontSize: 14,
    '& div': {
      padding: '5px',
    },
  },
  search: {
    display: 'flex',
  },
  searchText: {
    display: 'flex',
    alignItems: 'center',
    border: '1px solid #dbdbdb',
    paddingLeft: 12,
    marginLeft: 10,
    width: 225,
    height: 30,
    fontSize: 14,
  },
  searchInput: {
    border: 'none',
    outline: 'none',
    flexGrow: 1,
  },
  searchButton: {
    padding: 3,
  },
}));

interface propsType {
  initializeData: () => void;
  openDialog: boolean;
  setOpenDialog: Dispatch<SetStateAction<boolean>>;
  selectedAction: { action: string; userId: string };
  setSelectedAction: Dispatch<
    SetStateAction<{ action: string; userId: string }>
  >;
  setUserData: Dispatch<SetStateAction<userType[]>>;
  orderUser: (
    node: userType[],
    order: 'asc' | 'desc',
    field: keyof userType
  ) => userType[];
  setAlert: (severity: 'success' | 'error', message: string) => void;
}

const UserManagementHeader = observer(
  ({
    initializeData,
    openDialog,
    setOpenDialog,
    selectedAction,
    setSelectedAction,
    setUserData,
    orderUser,
    setAlert,
  }: propsType) => {
    const searchRef = useRef<HTMLInputElement>(null);
    const classes = useStyles();
    const { UserStore } = useStore();
    const TITLE = 'Add New User';
    const MENU_ITEMS: { [key: string]: string } = {
      'User ID': 'userId',
      Name: 'userName',
      'E-mail': 'email',
      'Telephone No.': 'telNo',
    };

    const handleCreateClick = () => {
      setOpenDialog(true);
    };

    const handleSelectChange = (
      e: SelectChangeEvent<{ value: string | unknown }>
    ) => {
      UserStore.setSearchType(e.target.value as string);
    };

    const handleIconClick = () => {
      UserStore.setSearchText(searchRef?.current?.value || '');
      const newData = UserStore.userInfo.filter((data: userType) => {
        if (!searchRef.current) return false;
        if (
          !(data as unknown as { [key: string]: string })[
            MENU_ITEMS[UserStore.searchType]
          ]
        )
          return UserStore.searchText === '' ? true : false;
        return (data as unknown as { [key: string]: string })[
          MENU_ITEMS[UserStore.searchType]
        ].includes(UserStore.searchText);
      });
      UserStore.setSelectedUsers([]);
      setUserData(orderUser(newData, UserStore.order, UserStore.orderProperty));
    };

    const handleSubmitByEnter = (e: React.KeyboardEvent) => {
      if (e.key === 'Enter') {
        handleIconClick();
      }
    };

    return (
      <>
        <div className={classes.create} onClick={handleCreateClick}>
          <AddIcon />
          {TITLE}
        </div>
        <UserManagementHeaderDialog
          openDialog={openDialog}
          selectedAction={selectedAction}
          setSelectedAction={setSelectedAction}
          setOpenDialog={setOpenDialog}
          initializeData={initializeData}
          setAlert={setAlert}
        />
        <div className={classes.search}>
          <Select
            className={classes.select}
            value={UserStore.searchType as any}
            onChange={handleSelectChange}
            MenuProps={{
              anchorOrigin: {
                vertical: 'bottom',
                horizontal: 'left',
              },
              transformOrigin: {
                vertical: -5,
                horizontal: 5,
              },
            }}
          >
            {Object.keys(MENU_ITEMS).map((item: string, idx: number) => {
              return (
                <MenuItem
                  key={`user-management-header-select-${idx}`}
                  value={item}
                >
                  {item}
                </MenuItem>
              );
            })}
          </Select>
          <div className={classes.searchText}>
            <input
              className={classes.searchInput}
              type="text"
              ref={searchRef}
              onKeyDown={handleSubmitByEnter}
            ></input>
            <IconButton
              aria-label="search-button"
              className={classes.searchButton}
              onClick={handleIconClick}
              size="large"
            >
              <SearchIcon />
            </IconButton>
          </div>
        </div>
      </>
    );
  }
);

export default UserManagementHeader;
