import { useState, useEffect, Dispatch, SetStateAction } from 'react';
import {
  Dialog,
  DialogTitle,
  Divider,
  DialogContent,
  Button,
  DialogActions,
} from '@mui/material';
import makeStyles from '@mui/styles/makeStyles';
import { UserApi } from '@/apis';
import { useStore } from '@/utils';
import { DialogTextRow } from './UserManagementHeaderDialogRow';
import { userType } from '@/types/typeBundle';
import { initialUserValue } from './UserManagement';

const useStyles = makeStyles(() => ({
  dialog: {
    '& .MuiDialog-container': {
      minWidth: 695,
    },
  },
  dialogTitle: {
    '& h2': {
      fontSize: 16,
      fontWeight: 600,
      color: '#444',
    },
  },
  divider: {
    margin: '0px 20px',
  },
  dialogContent: {
    overflowX: 'hidden',
    '& p': {
      display: 'flex',
      alignItems: 'center',
      width: 175,
      fontSize: 14,
      margin: 0,
    },
    '& input': {
      padding: '5px 10px',
      width: 312,
      fontSize: 14,
      color: '#555',
    },
    '& input[type=radio]': {
      width: 'fit-content',
    },
    '& .Mui-disabled[type=text]': {
      backgroundColor: 'rgba(0, 0, 0, 0.1)',
    },
    '& .Mui-disabled[role=button]': {
      backgroundColor: 'rgba(0, 0, 0, 0.1)',
    },
  },
  dialogDelete: {
    padding: 50,
  },
}));

interface dialogPropsType {
  openDialog: boolean;
  selectedAction: { action: string; userId: string };
  setSelectedAction: Dispatch<
    SetStateAction<{ action: string; userId: string }>
  >;
  setOpenDialog: Dispatch<SetStateAction<boolean>>;
  initializeData: () => void;
  setAlert: (severity: 'success' | 'error', message: string) => void;
}

const UserManagementHeaderDialog = ({
  openDialog,
  selectedAction,
  setSelectedAction,
  setOpenDialog,
  initializeData,
  setAlert,
}: dialogPropsType) => {
  const [userValue, setUserValue] = useState<userType>(initialUserValue);
  const classes = useStyles();
  const { UserStore } = useStore();

  const handleCloseDialog = () => {
    setOpenDialog(false);
    setTimeout(() => {
      setUserValue(initialUserValue);
      setSelectedAction({ action: 'Create', userId: '' });
    }, 200);
  };

  const handleRequestSuccess = () => {
    handleCloseDialog();
    initializeData();
    setAlert('success', 'The request was successfully done.');
    UserStore.setSelectedUsers([]);
  };

  const checkSubmitValue = () => {
    const TITLES: { [key: string]: string } = {
      userId: 'User ID',
      userName: 'Name',
      userPasswd: 'Password',
      userDiv: 'User Div',
      email: 'E-mail',
      telNo: 'Telephone No.',
    };
    const emptyStrings: string[] = Object.entries(TITLES)
      .filter((title) => {
        return (
          (userValue as unknown as { [key: string]: string })[title[0]] === ''
        );
      })
      .map((title) => {
        return title[1];
      });
    if (emptyStrings.length > 0) {
      setAlert(
        'error',
        `Please enter values for the following: ${emptyStrings.join(', ')}`
      );
      return false;
    }
    return true;
  };

  const handleSubmitDialog = async () => {
    if (selectedAction.action === 'Delete') {
      const submitValue = UserStore.selectedUsers.map((userId: string) => {
        return {
          userId: userId,
          userPasswd: UserStore.getUserPassword(userId),
        };
      });
      const response = await UserApi.delete(submitValue);
      const errorMessage = (response as { data: { errorMsg: string } }).data
        ?.errorMsg;
      (response as { data: { success: boolean } }).data?.success
        ? handleRequestSuccess()
        : setAlert('error', `Request failed: ${errorMessage}`);
      return;
    }
    if (checkSubmitValue()) {
      const response =
        selectedAction.action === 'Create'
          ? await UserApi.add(userValue)
          : await UserApi.edit(userValue);
      const errorMessage = (response as { data: { errorMsg: string } }).data
        ?.errorMsg;
      errorMessage
        ? setAlert('error', `Request failed: ${errorMessage}`)
        : handleRequestSuccess();
    }
  };

  const handleSelectedAction = async () => {
    const targetUser = UserStore.userInfo.filter((user: userType) => {
      return selectedAction.userId === user.userId;
    })[0];
    if (targetUser && targetUser.length === 0) {
      setAlert('error', 'There is no such user.');
      return;
    }
    setUserValue(targetUser);
    setOpenDialog(true);
  };

  useEffect(() => {
    if (selectedAction.action === 'Create') return;
    handleSelectedAction();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedAction]);

  return (
    <Dialog
      className={classes.dialog}
      maxWidth="md"
      open={openDialog}
      onClose={handleCloseDialog}
      aria-labelledby="form-dialog-title"
    >
      {selectedAction.action === 'Delete' ? (
        <>
          <DialogTitle className={classes.dialogTitle} id="form-dialog-title">
            Delete User
          </DialogTitle>
          <Divider className={classes.divider} />
          <DialogContent className={classes.dialogDelete}>
            Are you sure to delete all checked users?
          </DialogContent>
          <DialogActions>
            <Button
              onClick={handleSubmitDialog}
              color="primary"
              variant="contained"
            >
              OK
            </Button>
            <Button
              color="inherit"
              onClick={handleCloseDialog}
              variant="contained"
            >
              Cancel
            </Button>
          </DialogActions>
        </>
      ) : (
        <>
          <DialogTitle className={classes.dialogTitle}>{`${
            selectedAction.action === 'Create' ? 'Add' : selectedAction.action
          } User`}</DialogTitle>
          <Divider className={classes.divider} />
          <DialogContent className={classes.dialogContent}>
            <DialogTextRow
              selectedAction={selectedAction}
              userValue={userValue}
              setUserValue={setUserValue}
              title="User ID*"
              name="userId"
              value={userValue.userId}
            />
            <DialogTextRow
              selectedAction={selectedAction}
              userValue={userValue}
              setUserValue={setUserValue}
              title="Password*"
              name="userPasswd"
              value={userValue.userPasswd}
            />
            <DialogTextRow
              selectedAction={selectedAction}
              userValue={userValue}
              setUserValue={setUserValue}
              title="Name*"
              name="userName"
              value={userValue.userName}
            />
            <DialogTextRow
              selectedAction={selectedAction}
              userValue={userValue}
              setUserValue={setUserValue}
              title="User Div*"
              name="userDiv"
              value={userValue.userDiv}
            />
            <DialogTextRow
              selectedAction={selectedAction}
              userValue={userValue}
              setUserValue={setUserValue}
              title="E-mail*"
              name="email"
              value={userValue.email}
            />
            <DialogTextRow
              selectedAction={selectedAction}
              userValue={userValue}
              setUserValue={setUserValue}
              title="Telephone No.*"
              name="telNo"
              value={userValue.telNo}
            />
          </DialogContent>
          <DialogActions>
            <Button
              onClick={handleSubmitDialog}
              color="primary"
              variant="contained"
            >
              {selectedAction.action}
            </Button>
            <Button
              color="inherit"
              onClick={handleCloseDialog}
              variant="contained"
            >
              Cancel
            </Button>
          </DialogActions>
        </>
      )}
    </Dialog>
  );
};

export default UserManagementHeaderDialog;
