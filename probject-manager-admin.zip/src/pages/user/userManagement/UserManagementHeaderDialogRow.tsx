import { Dispatch, SetStateAction } from 'react';
import { TextField, DialogContentText } from '@mui/material';
import makeStyles from '@mui/styles/makeStyles';
import { userType } from '@/types/typeBundle';

const useStyles = makeStyles(() => ({
  dialogTitle: {
    '& h2': {
      fontSize: 16,
      fontWeight: 600,
      color: '#444',
    },
  },
  dialogBox: {
    display: 'flex',
    margin: '12px 35px',
    '& :disabled': {
      backgroundColor: 'rgba(0, 0, 0, 0.1)',
    },
  },
}));

interface RowPropsType {
  selectedAction: { action: string; userId: string };
  userValue: userType;
  setUserValue: Dispatch<SetStateAction<userType>>;
  title: string;
  name: string;
  value: string;
}

export const DialogTextRow = ({
  selectedAction,
  userValue,
  setUserValue,
  title,
  name,
  value,
}: RowPropsType) => {
  const classes = useStyles();
  const disabled = selectedAction.action === 'Edit' && title === 'User ID*';
  const type = title === 'Password*' ? 'password' : 'text';

  const handleTextChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setUserValue({ ...userValue, [e.target.name]: e.target.value });
  };

  return (
    <div className={classes.dialogBox}>
      <DialogContentText className={classes.dialogTitle}>
        {title}
      </DialogContentText>
      <TextField
        name={name}
        value={value ? value : ''}
        disabled={disabled}
        type={type}
        autoComplete="off"
        onChange={handleTextChange}
        spellCheck="false"
      />
    </div>
  );
};
