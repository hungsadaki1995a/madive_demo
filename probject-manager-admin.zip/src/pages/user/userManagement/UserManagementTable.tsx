import React, {
  useState,
  useEffect,
  useCallback,
  Dispatch,
  SetStateAction,
} from 'react';
import { observer } from 'mobx-react';
import {
  Table,
  TableHead,
  TableBody,
  TableCell,
  TableContainer,
  TablePagination,
  TableRow,
  TableSortLabel,
} from '@mui/material';
import makeStyles from '@mui/styles/makeStyles';
import CheckBox from '@mui/material/Checkbox';
import { useStore } from '@/utils';
import {
  userType,
  userSelectionType,
  paginationType,
} from '@/types/typeBundle';
import { TableBodyContents, TableEmpty } from '@/components/molecules';

const useStyles = makeStyles(() => ({
  pagination: {
    position: 'fixed',
    bottom: 20,
    borderBottom: 'none',
    minWidth: 1330,
    width: 'calc(100vw - 310px)',
    '& div p, div div': {
      fontSize: '0.875rem',
      color: '#000',
    },
  },
  checkboxContainer: {
    width: 24,
  },
  emptyHeader: {
    display: 'none',
  },
}));

interface propsType {
  userData: userType[];
  pagination: paginationType;
  setPagination: Dispatch<SetStateAction<paginationType>>;
}

const UserManagementTable = observer(
  ({ userData, pagination, setPagination }: propsType) => {
    const [data, setData] = useState<userSelectionType[]>([]);
    const classes = useStyles();
    const { UserStore } = useStore();
    const columns = [
      { title: 'Selection', field: 'selection' },
      { title: 'User ID', field: 'userId' },
      { title: 'Name', field: 'userName' },
      { title: 'E-mail', field: 'email' },
      { title: 'User Div', field: 'userDiv' },
      { title: 'Telephone No.', field: 'telNo' },
    ];

    const orderTable = (
      user: userSelectionType[],
      order: 'asc' | 'desc',
      field: keyof userSelectionType
    ) => {
      return user.sort((a, b) => {
        if (a[field] === null) return order === 'asc' ? -1 : 1;
        if (b[field] === null) return order === 'asc' ? 1 : -1;
        let thisOrder = 0;
        String(Number(a[field])) === a[field] &&
        String(Number(b[field])) === b[field]
          ? (thisOrder =
              Number(a[field]) > Number(b[field])
                ? 1
                : Number(a[field]) < Number(b[field])
                ? -1
                : 0)
          : (thisOrder =
              a[field] > b[field] ? 1 : a[field] < b[field] ? -1 : 0);
        return order === 'asc' ? thisOrder : thisOrder * -1;
      });
    };

    const handleOrderTable = (field: keyof userSelectionType) => {
      const newOrder =
        field === UserStore.orderProperty
          ? UserStore.order === 'asc'
            ? 'desc'
            : 'asc'
          : 'asc';
      UserStore.setOrderProperty(field);
      UserStore.setOrder(newOrder);
      setData(orderTable(data, newOrder, field));
    };

    const handleHeaderCheckboxChange = () => {
      const allDataChecked = UserStore.selectedUsers.length === data.length;
      const newSelectedData = !allDataChecked
        ? data.map((user) => {
            return user.userId;
          })
        : [];
      UserStore.setSelectedUsers(newSelectedData);
      setData(orderTable(data, UserStore.order, UserStore.orderProperty));
    };

    const handlePageChange = async (
      e: React.MouseEvent | null,
      page: number
    ) => {
      setPagination({ ...pagination, page: page });
    };

    const handleRowsPerPageChange = (e: React.ChangeEvent) => {
      const newPageSize = Number((e.target as HTMLInputElement).value);
      setPagination({ ...pagination, pageSize: newPageSize });
      setData(orderTable(data, UserStore.order, UserStore.orderProperty));
    };

    const setNewData = useCallback(() => {
      const handleBodyCheckboxClick = (user: userType) => {
        const selectedData = UserStore.selectedUsers;
        const newSelectedData = selectedData.includes(user.userId)
          ? selectedData.filter((userId: string) => {
              return userId !== user.userId;
            })
          : [...selectedData, user.userId];
        UserStore.setSelectedUsers(newSelectedData);
      };
      const newData = userData
        .filter((_, idx) => {
          return (
            idx >= pagination.page * pagination.pageSize &&
            idx < (pagination.page + 1) * pagination.pageSize
          );
        })
        .map((user) => {
          return {
            ...user,
            selection: (
              <CheckBox
                color="info"
                checked={UserStore.selectedUsers.includes(user.userId)}
                onClick={() => handleBodyCheckboxClick(user)}
              />
            ),
          };
        });
      setData(orderTable(newData, UserStore.order, UserStore.orderProperty));
    }, [UserStore, userData, pagination.page, pagination.pageSize]);

    useEffect(() => {
      setNewData();
    }, [setNewData, UserStore.selectedUsers]);

    return (
      <TableContainer>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell className={classes.checkboxContainer}>
                <CheckBox
                  color="info"
                  checked={
                    UserStore.selectedUsers.length !== 0 &&
                    UserStore.selectedUsers.length === data.length
                  }
                  onChange={handleHeaderCheckboxChange}
                />
              </TableCell>
              {columns.map((column, idx) => {
                return column.field === 'selection' ? (
                  <td
                    key={`user-head-${idx}`}
                    className={classes.emptyHeader}
                  ></td>
                ) : (
                  <TableCell key={`user-head-${idx}`}>
                    <TableSortLabel
                      active={UserStore.orderProperty === column.field}
                      direction={
                        UserStore.orderProperty === column.field
                          ? UserStore.order
                          : 'asc'
                      }
                      onClick={() =>
                        handleOrderTable(
                          column.field as keyof userSelectionType
                        )
                      }
                    >
                      {column.title}
                    </TableSortLabel>
                  </TableCell>
                );
              })}
            </TableRow>
          </TableHead>
          <TableBody>
            {data.length === 0 ? (
              <TableEmpty />
            ) : (
              <TableBodyContents data={data} columns={columns} />
            )}
            <TableRow>
              <TablePagination
                className={classes.pagination}
                rowsPerPageOptions={[10, 25, 50]}
                count={pagination.totalCount}
                rowsPerPage={pagination.pageSize}
                page={pagination.page}
                onPageChange={handlePageChange}
                onRowsPerPageChange={handleRowsPerPageChange}
              />
            </TableRow>
          </TableBody>
        </Table>
      </TableContainer>
    );
  }
);

export default UserManagementTable;
