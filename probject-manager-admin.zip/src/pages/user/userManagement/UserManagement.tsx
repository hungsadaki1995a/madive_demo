import { useEffect, useState } from 'react';
import { observer } from 'mobx-react';
import makeStyles from '@mui/styles/makeStyles';
import UserManagementHeader from './UserManagementHeader';
import UserManagementTable from './UserManagementTable';
import UserManagementButtons from './UserManagementButtons';
import { paginationType, userType } from '@/types/typeBundle';
import { UserApi } from '@/apis';
import { useStore } from '@/utils';

const useStyles = makeStyles(() => ({
  wrap: {
    width: 'calc(100vw - 240px)',
    height: 'calc(100vh - 50px)',
  },
  title: {
    padding: 13,
    minWidth: 200,
    color: 'rgb(39, 111, 195)',
  },
  contents: {
    padding: 20,
    width: 'calc(100vw - 280px)',
    minWidth: 1360,
    height: 'calc(100vh - 135px)',
    minHeight: 750,
    backgroundColor: '#E8EDF1',
  },
  contentsWrap: {
    width: '100%',
    height: '100%',
    backgroundColor: '#fff',
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '10px 10px 5px',
  },
  table: {
    padding: 12,
    maxHeight: 660,
    overflowY: 'auto',
    '& table': {
      tableLayout: 'fixed',
    },
    '& div': {
      boxShadow: 'none',
    },
    '& thead tr': {
      position: 'sticky',
      top: 0,
      zIndex: 1,
    },
    '& thead tr th': {
      fontSize: 12,
      fontWeight: 600,
      backgroundColor: '#f4f7fc',
      whiteSpace: 'nowrap',
      padding: 12,
      '& span': {
        padding: 0,
      },
    },
    '& tbody': {
      padding: '0 16px',
      backgroundColor: '#fff',
      '& tr:hover': {
        backgroundColor: '#e6f4ff',
        '& td': {
          fontWeight: 600,
          color: '#000',
        },
      },
      '& td': {
        padding: 12,
        fontSize: 12,
        whiteSpace: 'nowrap',
        fontWeight: 450,
        color: '#888',
        '& span': {
          padding: 0,
        },
      },
    },
  },
  buttons: {
    position: 'fixed',
    bottom: 30,
    padding: '10px 10px 5px',
    '& :disabled': {
      backgroundColor: '#000',
      cursor: 'not-allowed',
    },
  },
}));

export const initialUserValue = {
  email: '',
  telNo: '',
  userDiv: '',
  userId: '',
  userName: '',
  userPasswd: '',
};

const UserManagement = observer(({ title }: { title: string }) => {
  const [pagination, setPagination] = useState<paginationType>({
    page: 0,
    pageSize: 10,
    totalCount: 0,
  });
  const [disabledButtons, setDisabledButtons] = useState<{
    change: boolean;
    delete: boolean;
  }>({ change: true, delete: true });
  const [openDialog, setOpenDialog] = useState<boolean>(false);
  const [selectedAction, setSelectedAction] = useState<{
    action: string;
    userId: string;
  }>({ action: 'Create', userId: '' });
  const [userData, setUserData] = useState<userType[]>([]);
  const classes = useStyles();
  const { UserStore, AlertStore } = useStore();
  const STATUS = { isFetching: false };
  const MENU_ITEMS: { [key: string]: string } = {
    'User ID': 'userId',
    Name: 'userName',
    'E-mail': 'email',
    'Telephone No.': 'telNo',
  };

  const orderUser = (
    user: userType[],
    order: 'asc' | 'desc',
    field: keyof userType
  ) => {
    const thisOrder = order === 'asc' ? 1 : -1;
    return user.sort((a, b) => {
      const newOrder =
        String(a[field]) > String(b[field])
          ? 1
          : String(a[field]) < String(b[field])
          ? -1
          : 0;
      return newOrder * thisOrder;
    });
  };

  const initializeData = async () => {
    STATUS.isFetching = true;
    const data = await UserApi.get('/userList');
    if (data?.userInfoDTOArray) {
      UserStore.setUsers(data.userInfoDTOArray);
      UserStore.setSelectedUsers([]);
      const newUser = UserStore.userInfo.filter((data: userType) => {
        if (
          !(data as unknown as { [key: string]: string })[
            MENU_ITEMS[UserStore.searchType]
          ]
        )
          return UserStore.searchText === '' ? true : false;
        return (data as unknown as { [key: string]: string })[
          MENU_ITEMS[UserStore.searchType]
        ].includes(UserStore.searchText);
      });
      setUserData(orderUser(newUser, UserStore.order, UserStore.orderProperty));
      setPagination({
        ...pagination,
        totalCount: data.userInfoDTOArray.length,
      });
    }
    STATUS.isFetching = false;
  };

  const setAlert = async (severity: 'error' | 'success', message: string) => {
    AlertStore.openApiAlert(severity, message);
  };

  useEffect(() => {
    if (STATUS.isFetching) return;
    UserStore.setSearchType('User ID');
    UserStore.setSearchText('');
    UserStore.setOrder('asc');
    UserStore.setOrderProperty('userId');
    initializeData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    setPagination({ ...pagination, page: 0, totalCount: userData.length });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userData]);

  useEffect(() => {
    if (UserStore.selectedUsers.length === 0) {
      setDisabledButtons({ change: true, delete: true });
    } else if (UserStore.selectedUsers.length === 1) {
      setDisabledButtons({ change: false, delete: false });
    } else {
      setDisabledButtons({ change: true, delete: false });
    }
  }, [UserStore.selectedUsers]);

  return (
    <div className={classes.wrap}>
      <div className={classes.title}>{title}</div>
      <div className={classes.contents}>
        <div className={classes.contentsWrap}>
          <div className={classes.header}>
            <UserManagementHeader
              initializeData={initializeData}
              openDialog={openDialog}
              setOpenDialog={setOpenDialog}
              selectedAction={selectedAction}
              setSelectedAction={setSelectedAction}
              setUserData={setUserData}
              orderUser={orderUser}
              setAlert={setAlert}
            />
          </div>
          <div className={classes.table}>
            <UserManagementTable
              userData={userData}
              pagination={pagination}
              setPagination={setPagination}
            />
          </div>
          <div className={classes.buttons}>
            <UserManagementButtons
              disabledButtons={disabledButtons}
              setSelectedAction={setSelectedAction}
              setAlert={setAlert}
            />
          </div>
        </div>
      </div>
    </div>
  );
});

export default UserManagement;
