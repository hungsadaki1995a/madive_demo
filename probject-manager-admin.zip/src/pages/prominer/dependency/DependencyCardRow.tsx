import { Dispatch, SetStateAction } from 'react';
import {
  TextField,
  Select,
  SelectChangeEvent,
  MenuItem,
  DialogContentText,
} from '@mui/material';
import makeStyles from '@mui/styles/makeStyles';
import { dependencyType } from '@/types/typeBundle';

const useStyles = makeStyles(() => ({
  dialogTitle: {
    '& h2': {
      fontSize: 16,
      fontWeight: 600,
      color: '#444',
    },
  },
  dialogBox: {
    display: 'flex',
    justifyContent: 'space-between',
    margin: '12px 35px',
    width: 500,
  },
  dialogSelect: {
    width: 332.5,
    fontSize: 14,
    '& div': {
      padding: '5px 10px',
    },
  },
}));

interface RowPropsType {
  dependencyValue: dependencyType;
  setDependencyValue: Dispatch<SetStateAction<dependencyType>>;
  title: string;
  name: string;
  value: string | boolean;
}

export const DialogTextRow = ({
  dependencyValue,
  setDependencyValue,
  title,
  name,
  value,
}: RowPropsType) => {
  const classes = useStyles();

  const handleTextChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const target = e.target;
    setDependencyValue({ ...dependencyValue, [target.name]: target.value });
  };

  return (
    <div className={classes.dialogBox}>
      <DialogContentText className={classes.dialogTitle}>
        {title}
      </DialogContentText>
      <TextField
        name={name}
        value={value}
        onChange={handleTextChange}
        spellCheck="false"
      />
    </div>
  );
};

export const DialogSelectRow = ({
  dependencyValue,
  setDependencyValue,
  title,
  name,
  value,
}: RowPropsType) => {
  const classes = useStyles();
  const selectItems: { [key: string]: string[] } = {
    gitPlatformType: ['Private Gitlab', 'Public Gitlab', 'Github'],
  };

  const handleSelectChange = (
    e: SelectChangeEvent<{ value: string | unknown }>
  ) => {
    setDependencyValue({
      ...dependencyValue,
      [e.target.name]: e.target.value as string,
    });
  };

  return (
    <div className={classes.dialogBox}>
      <DialogContentText className={classes.dialogTitle}>
        {title}
      </DialogContentText>
      <Select
        id={name}
        name={name}
        value={value as any}
        className={classes.dialogSelect}
        onChange={handleSelectChange}
        MenuProps={{
          anchorOrigin: {
            vertical: 'bottom',
            horizontal: 'left',
          },
          transformOrigin: {
            vertical: 0,
            horizontal: 0,
          },
        }}
      >
        {selectItems[name] ? (
          selectItems[name].map((item, idx) => (
            <MenuItem value={item} key={`menu-item-${idx}`}>
              {item}
            </MenuItem>
          ))
        ) : (
          <MenuItem value="">No Option Available</MenuItem>
        )}
      </Select>
    </div>
  );
};
