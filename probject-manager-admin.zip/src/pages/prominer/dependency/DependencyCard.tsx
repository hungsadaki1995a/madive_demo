import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent } from '@mui/material';
import makeStyles from '@mui/styles/makeStyles';
import { DialogTextRow, DialogSelectRow } from './DependencyCardRow';
import { DependencyApi } from '@/apis';
import { dependencyType } from '@/types/typeBundle';
import { useStore } from '@/utils';

const useStyles = makeStyles(() => ({
  card: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    width: 700,
    height: 450,
  },
  cardContent: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    '& input': {
      padding: '5px 10px',
      width: 312,
      fontSize: 14,
      color: '#555',
    },
  },
  cardTitle: {
    marginBottom: 20,
    fontSize: 20,
    fontWeight: 600,
  },
  button: {
    border: 'none',
    marginTop: 20,
    width: 90,
    height: 35,
    color: '#fff',
    backgroundColor: '#4085ee',
    cursor: 'pointer',
  },
  guide: {
    color: 'rgba(0, 0, 0, 0.5)',
    fontSize: 11,
    transform: 'translate(50px, -10px)',
  },
  cover: {
    position: 'absolute',
    top: 0,
    left: 0,
    width: '100vw',
    height: '100vh',
    backgroundColor: 'rgba(0, 0, 0, 0.2)',
  },
}));

interface propsType {
  setAlert: (severity: 'success' | 'error', message: string) => void;
}

const DependencyCard = ({ setAlert }: propsType) => {
  const [dependencyValue, setDependencyValue] = useState<dependencyType>({
    gitUrl: '',
    name: '',
    gitToken: '',
    gitPlatformType: '',
    gitBranch: '',
  });
  const [cover, setCover] = useState<JSX.Element>(<></>);
  const classes = useStyles();
  const navigate = useNavigate();
  const { ProminerStore } = useStore();

  const checkSubmitValue = () => {
    const TITLES: { [key: string]: string } = {
      gitUrl: 'Git URL',
      name: 'Name',
      gitToken: 'Git Token',
      gitPlatformType: 'Git Platform Type',
    };
    const emptyStrings: string[] = Object.entries(TITLES)
      .filter((title) => {
        return (
          (dependencyValue as unknown as { [key: string]: string })[
            title[0]
          ] === ''
        );
      })
      .map((title) => {
        return title[1];
      });
    if (emptyStrings.length > 0) {
      setAlert(
        'error',
        `Please enter values for the following: ${emptyStrings.join(', ')}`
      );
      return false;
    }
    return true;
  };

  const handleSubmit = async () => {
    if (checkSubmitValue()) {
      setCover(<div className={classes.cover} />);
      const response = await DependencyApi.getDependencies(dependencyValue);
      setCover(<></>);
      if (response.message) {
        const errorMessage =
          response?.response?.data?.messages.join(' ') || response.message;
        setAlert('error', `Request Failed: ${errorMessage}`);
        return;
      }
      ProminerStore.setDependency(response);
      sessionStorage.setItem('dependencyId', String(response.id));
      navigate(`/development/prominer/dependency/${response.id}`);
    }
  };

  useEffect(() => {
    const dependencyId = sessionStorage.getItem('dependencyId');
    if (!dependencyId) return;
    navigate(`/development/prominer/dependency/${dependencyId}`);
  }, [navigate, ProminerStore]);

  return (
    <Card className={classes.card}>
      <CardContent className={classes.cardContent}>
        <div className={classes.cardTitle}>Analyze Code</div>
        <DialogTextRow
          dependencyValue={dependencyValue}
          setDependencyValue={setDependencyValue}
          title="Git URL*"
          name="gitUrl"
          value={dependencyValue.gitUrl}
        />
        <DialogTextRow
          dependencyValue={dependencyValue}
          setDependencyValue={setDependencyValue}
          title="Name*"
          name="name"
          value={dependencyValue.name}
        />
        <DialogTextRow
          dependencyValue={dependencyValue}
          setDependencyValue={setDependencyValue}
          title="Git Token*"
          name="gitToken"
          value={dependencyValue.gitToken}
        />
        <DialogSelectRow
          dependencyValue={dependencyValue}
          setDependencyValue={setDependencyValue}
          title="Git Platform Type*"
          name="gitPlatformType"
          value={dependencyValue.gitPlatformType}
        />
        <DialogTextRow
          dependencyValue={dependencyValue}
          setDependencyValue={setDependencyValue}
          title="Git Branch"
          name="gitBranch"
          value={dependencyValue.gitBranch}
        />
        <span className={classes.guide}>
          HEAD commit's branch will be brought if not entered.
        </span>
        <button className={classes.button} onClick={handleSubmit}>
          Start
        </button>
      </CardContent>
      {cover}
    </Card>
  );
};

export default DependencyCard;
