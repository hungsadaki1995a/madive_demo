import { useState } from 'react';
import {
  TextField,
  Select,
  SelectChangeEvent,
  MenuItem,
  Radio,
  RadioGroup,
  FormControlLabel,
} from '@mui/material';
import makeStyles from '@mui/styles/makeStyles';
import { useStore } from '@/utils';
import { DependencyApi } from '@/apis';

const useStyles = makeStyles(() => ({
  row: {
    display: 'flex',
    alignItems: 'center',
  },
  title: {
    margin: 25,
    fontWeight: 600,
  },
  dialogSelect: {
    width: 250,
    fontSize: 14,
    '& div': {
      padding: '5px 10px',
    },
  },
  radioGroup: {
    '& span': {
      fontSize: 14,
    },
  },
  name: {
    '& input': {
      padding: '5px 10px',
    },
  },
  button: {
    border: 'none',
    borderRadius: 0,
    padding: '5px 0',
    margin: '0 50px',
    width: 90,
    height: 35,
    color: '#fff',
    backgroundColor: '#4085ee',
    cursor: 'pointer',
  },
}));

interface propsType {
  setAlert: (severity: 'success' | 'error', message: string) => void;
}

const DependencyAnalysisSettings = ({ setAlert }: propsType) => {
  const { ProminerStore } = useStore();
  const [selectValue, setSelectValue] = useState<number | ''>(
    ProminerStore.dependencySettings.project
  );
  const [radioValue, setRadioValue] = useState<string>(
    ProminerStore.dependencySettings.type
  );
  const [directionValue, setDirectionValue] = useState<string>(
    ProminerStore.dependencySettings.direction
  );
  const [nameValue, setNameValue] = useState<string>(
    ProminerStore.dependencySettings.name
  );
  const classes = useStyles();
  const directionItems: string[] = ['Backward', 'Forward'];
  const radioItems: string[] = [
    'PO Controller',
    'Spring Controller',
    'Service',
    'Remote Service',
    'DAO',
    'DTO',
    'ALL',
  ];
  const radioValues: { [key: string]: string } = {
    'PO Controller': 'PO_CONTROLLER',
    'Spring Controller': 'SPRING_CONTROLLER',
    Service: 'SERVICE',
    'Remote Service': 'REMOTE_SERVICE',
  };

  const handleSelectChange = (
    e: SelectChangeEvent<{ value: string | unknown }>
  ) => {
    setSelectValue(Number(e.target.value));
  };

  const handleRadioChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setRadioValue(e.target.value);
  };

  const handleDirectionChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setDirectionValue(e.target.value);
    ProminerStore.setDependencyDirection(
      e.target.value === 'Forward' ? 'FORWARD' : 'BACKWARD'
    );
  };

  const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setNameValue(e.target.value);
  };

  const handleClickButton = async () => {
    if (selectValue === '') {
      setAlert('error', 'Please select a value for Projects');
      return;
    }
    const projectId: number = ProminerStore.dependencyValue.projects.find(
      (project: { id: number; name: string }) => {
        return project.id === selectValue;
      }
    ).id;
    const params: { [key: string]: number | string } = {
      projectId: projectId,
      type: radioValues[radioValue] ?? radioValue,
      name: nameValue,
    };
    const response = await DependencyApi.getResources(params);
    if (response.message) {
      setAlert('error', `Request failed: ${response.message}`);
      return;
    }
    ProminerStore.setResources(response);
    ProminerStore.setDependencySettings({
      project: selectValue,
      type: radioValue,
      direction: directionValue,
      name: nameValue,
    });
  };

  const handleSubmitByEnter = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleClickButton();
    }
  };

  return (
    <>
      <div className={classes.row}>
        <span className={classes.title}>Projects:</span>
        <Select
          value={selectValue as any}
          className={classes.dialogSelect}
          onChange={handleSelectChange}
          MenuProps={{
            anchorOrigin: {
              vertical: 'bottom',
              horizontal: 'left',
            },
            transformOrigin: {
              vertical: 0,
              horizontal: 0,
            },
          }}
        >
          {ProminerStore.dependencyValue.projects.map(
            (project: { id: number; name: string }, idx: number) => {
              const { id, name } = project;
              return (
                <MenuItem value={id} key={`menu-item-${idx}`}>
                  {name}
                </MenuItem>
              );
            }
          )}
        </Select>
        <span className={classes.title}>Type:</span>
        <RadioGroup row className={classes.radioGroup} value={radioValue}>
          {radioItems.map((item, idx) => (
            <FormControlLabel
              key={`radio-item-${idx}`}
              value={item}
              control={<Radio onChange={handleRadioChange} />}
              label={item}
            />
          ))}
        </RadioGroup>
      </div>
      <div className={classes.row}>
        <span className={classes.title}>Direction:</span>
        <RadioGroup row className={classes.radioGroup} value={directionValue}>
          {directionItems.map((item, idx) => (
            <FormControlLabel
              key={`radio-item-${idx}`}
              value={item}
              control={<Radio onChange={handleDirectionChange} />}
              label={item}
            />
          ))}
        </RadioGroup>
        <span className={classes.title}>Name:</span>
        <TextField
          className={classes.name}
          value={nameValue}
          autoComplete="off"
          onChange={handleNameChange}
          onKeyDown={handleSubmitByEnter}
          spellCheck="false"
        />
        <button className={classes.button} onClick={handleClickButton}>
          Search
        </button>
      </div>
    </>
  );
};

export default DependencyAnalysisSettings;
