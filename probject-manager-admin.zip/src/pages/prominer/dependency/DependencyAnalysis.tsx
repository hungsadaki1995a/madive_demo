import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@mui/material';
import makeStyles from '@mui/styles/makeStyles';
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';
import DependencyAnalysisSettings from './DependencyAnalysisSettings';
import DependencyAnalysisContents from './DependencyAnalysisContents';
import { useStore } from '@/utils';
import DependencyAnalysisDialog from './DependencyAnalysisDialog';
import { DependencyApi } from '@/apis';
import { dependencyResponseType } from '@/types/typeBundle';

const useStyles = makeStyles(() => ({
  wrap: {
    width: 'calc(100vw - 240px)',
    height: 'calc(100vh - 50px)',
  },
  title: {
    padding: 13,
    minWidth: 200,
    color: 'rgb(39, 111, 195)',
  },
  contents: {
    padding: 20,
    width: 'calc(100vw - 280px)',
    minWidth: 1360,
    height: 'calc(100vh - 135px)',
    minHeight: 750,
    backgroundColor: '#E8EDF1',
  },
  contentsWrap: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
    height: '100%',
    backgroundColor: '#fff',
    overflowY: 'auto',
  },
  analysisWrap: {
    display: 'flex',
    flexDirection: 'column',
    width: '100%',
    height: '100%',
  },
  button: {
    justifyContent: 'flex-start',
    margin: 10,
    width: 'fit-content',
  },
  icon: {
    color: '#2196f3',
  },
  analysisTitle: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
  },
  info: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'flex-end',
    margin: 20,
    '& div': {
      margin: '5px 0',
    },
  },
}));

interface propsType {
  title: string;
}

const DependencyAnalysis = ({ title }: propsType) => {
  const { ProminerStore, AlertStore } = useStore();
  const [openDialog, setOpenDialog] = useState<boolean>(false);
  const [dependency, setDependency] = useState<dependencyResponseType>(
    ProminerStore.dependencyValue
  );
  const classes = useStyles();
  const navigate = useNavigate();
  const date = new Date(ProminerStore.dependencyValue.createdAt);

  const setAlert = useCallback(
    (severity: 'error' | 'success', message: string) => {
      AlertStore.openApiAlert(severity, message);
    },
    [AlertStore]
  );

  const handleClick = () => {
    setOpenDialog(true);
  };

  const initializeDependency = useCallback(async () => {
    const response = await DependencyApi.refreshedDependency(
      Number(sessionStorage.getItem('dependencyId'))
    );
    if (response.message) {
      setAlert('error', `Request failed: ${response.message}`);
    } else {
      ProminerStore.setDependency(response);
      setDependency(response);
    }
  }, [ProminerStore, setAlert]);

  useEffect(() => {
    !sessionStorage.getItem('dependencyId')
      ? navigate('/development/prominer/dependency')
      : initializeDependency();
  }, [navigate, initializeDependency]);

  return (
    <div className={classes.wrap}>
      <div className={classes.title}>{title}</div>
      <div className={classes.contents}>
        <div className={classes.contentsWrap}>
          <div className={classes.analysisWrap}>
            <Button className={classes.button} onClick={handleClick}>
              <ArrowBackIosIcon className={classes.icon} />
              New Analysis
            </Button>
            <div className={classes.analysisTitle}>
              <h1>{dependency.repository.name}</h1>
              <div>{`${dependency.repository.branchName}-${dependency.repository.lastCommitId}`}</div>
            </div>
            <div className={classes.info}>
              <div>{date.toDateString()}</div>
              <a
                href={dependency.repository.url}
                rel="noreferrer"
                target="_blank"
              >
                Git Repo
              </a>
            </div>
            <DependencyAnalysisSettings setAlert={setAlert} />
            <DependencyAnalysisContents setAlert={setAlert} />
            <DependencyAnalysisDialog
              openDialog={openDialog}
              setOpenDialog={setOpenDialog}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default DependencyAnalysis;
