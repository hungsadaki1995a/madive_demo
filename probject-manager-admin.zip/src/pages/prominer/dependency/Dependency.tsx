import { styled } from '@mui/material';
import { useStore } from '@/utils';
import DependencyCard from './DependencyCard';

const Dependency = ({ title }: { title: string }) => {
  const { AlertStore } = useStore();

  const setAlert = async (severity: 'error' | 'success', message: string) => {
    AlertStore.openApiAlert(severity, message);
  };

  return (
    <Wrap>
      <Title>{title}</Title>
      <Contents>
        <ContentsWrap>
          <DependencyCard setAlert={setAlert} />
        </ContentsWrap>
      </Contents>
    </Wrap>
  );
};

export default Dependency;

const Wrap = styled('div')({
  width: 'calc(100vw - 240px)',
  height: 'calc(100vh - 50px)',
});

const Title = styled('div')({
  padding: 13,
  minWidth: 200,
  color: 'rgb(39, 111, 195)',
});

const Contents = styled('div')({
  padding: 20,
  width: 'calc(100vw - 280px)',
  minWidth: 1360,
  height: 'calc(100vh - 135px)',
  minHeight: 750,
  backgroundColor: '#E8EDF1',
});

const ContentsWrap = styled('div')({
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  width: '100%',
  height: '100%',
  backgroundColor: '#fff',
  overflowY: 'auto',
});
