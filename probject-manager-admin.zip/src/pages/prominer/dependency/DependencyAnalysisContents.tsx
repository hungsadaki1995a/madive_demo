import { observer } from 'mobx-react';
import makeStyles from '@mui/styles/makeStyles';
import { useStore } from '@/utils';
import { resourceResponseType } from '@/types/typeBundle';
import DependencyAnalysisContentsRow from './DependencyAnalysisContentsRow';

const useStyles = makeStyles(() => ({
  wrap: {
    margin: '20px 10px',
  },
  firstRow: {
    display: 'flex',
    justifyContent: 'space-between',
    position: 'sticky',
    paddingTop: 10,
    top: 0,
    backgroundColor: '#fff',
    zIndex: 2,
    '& span': {
      justifyContent: 'center',
      borderBottom: '2px solid #000',
      paddingBottom: 10,
      fontWeight: 600,
    },
  },
  content: {
    display: 'flex',
    justifyContent: 'center',
    width: '30%',
  },
}));

interface propsType {
  setAlert: (severity: 'success' | 'error', message: string) => void;
}

const DependencyAnalysisContents = observer(({ setAlert }: propsType) => {
  const classes = useStyles();
  const { ProminerStore } = useStore();

  return (
    <div className={classes.wrap}>
      <span className={classes.firstRow}>
        <span className={classes.content}>Name</span>
        <span className={classes.content}>Package Name</span>
        <span className={classes.content}>Resource Type</span>
      </span>
      {ProminerStore.resourceValue.map(
        (resource: resourceResponseType, idx: number) => {
          return resource.id === -1 ? (
            <div key={`dependency-analysis-contents-${idx}`} />
          ) : (
            <DependencyAnalysisContentsRow
              key={`dependency-analysis-contents-${idx}`}
              resource={resource}
              id={resource.id}
              depth={0}
              setAlert={setAlert}
            />
          );
        }
      )}
    </div>
  );
});

export default DependencyAnalysisContents;
