import { Routes, Route, Navigate } from 'react-router-dom';
import Dependency from '@/pages/prominer/dependency/Dependency';
import DependencyAnalysis from '@/pages/prominer/dependency/DependencyAnalysis';
import { subMenusType } from '@/types/typeBundle';
import Error from '@/pages/error';

const Prominer = ({ subMenus }: { subMenus: subMenusType[] }) => {
  return (
    <Routes>
      <Route
        path="/dependency"
        element={<Dependency title={subMenus[0].title} />}
      />
      <Route
        path="/dependency/*"
        element={<DependencyAnalysis title={subMenus[0].title} />}
      />
      <Route
        path="/"
        element={<Navigate to="/development/prominer/dependency" />}
      />
      <Route path="/*" element={<Error />} />
    </Routes>
  );
};

export default Prominer;
