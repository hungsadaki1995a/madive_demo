import React, { useState, useEffect, useRef } from 'react';
import { observer } from 'mobx-react';
import { Box } from '@mui/material';
import makeStyles from '@mui/styles/makeStyles';
import ArrowRightIcon from '@mui/icons-material/ArrowRight';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import { useStore } from '@/utils';
import { DependencyApi } from '@/apis';
import { resourceResponseType } from '@/types/typeBundle';

const useStyles = makeStyles(() => ({
  row: {
    display: 'flex',
    justifyContent: 'space-between',
    padding: '10px 0',
  },
  content: {
    display: 'block',
    width: '30%',
    textAlign: 'center',
    textOverflow: 'ellipsis',
    whiteSpace: 'nowrap',
    overflow: 'hidden',
    backgroundColor: '#fff',
    zIndex: 1,
  },
  name: {
    display: 'flex',
    alignItems: 'center',
    textAlign: 'start',
    zIndex: 0,
  },
  icon: {
    cursor: 'pointer',
  },
}));

interface propsType {
  resource: resourceResponseType;
  id: number;
  depth: number;
  setAlert: (severity: 'success' | 'error', message: string) => void;
}

const DependencyAnalysisContentsRow = observer(
  ({ resource, id, depth, setAlert }: propsType) => {
    const classes = useStyles();
    const [nextData, setNextData] = useState<resourceResponseType[]>([]);
    const [icon, setIcon] = useState<JSX.Element>(
      <ArrowRightIcon className={classes.icon} />
    );
    const rowRef = useRef<HTMLDivElement>(null);
    const { ProminerStore } = useStore();
    const ROW_CLASS_NAME = 'dependency-analysis-contents-row';

    const handleRowClick = async (e: React.MouseEvent) => {
      const tagName = (e.target as HTMLElement).tagName;
      if (tagName !== 'svg' && tagName !== 'path') return;
      const { type } = icon.type;
      if (
        nextData.length > 0 ||
        type.render.displayName === 'ArrowDropDownIcon'
      ) {
        setIcon(<ArrowRightIcon className={classes.icon} />);
        setNextData([]);
        return;
      }
      const response = await DependencyApi.getResourceDetails(
        id,
        ProminerStore.dependencyDirection
      );
      if (response.error) {
        setAlert(
          'error',
          'Failed to find the data of the clicked row. Please try again.'
        );
        return;
      }
      const selfDependant = response.find(
        (res: { id: number }) => res.id === id
      );
      if (selfDependant) {
        response.splice(response.indexOf(selfDependant), 1);
      }
      if (response.length === 0) {
        setIcon(<ArrowDropDownIcon className={classes.icon} />);
        setAlert('success', 'Request success. No deeper dependency found.');
        return;
      }
      setIcon(<ArrowDropDownIcon className={classes.icon} />);
      setNextData(response);
    };

    useEffect(() => {
      setIcon(<ArrowRightIcon className={classes.icon} />);
      setNextData([]);
    }, [
      classes.icon,
      ProminerStore.resourceValue,
      ProminerStore.dependencyDirection,
    ]);

    return (
      <>
        <div
          className={`${classes.row} ${ROW_CLASS_NAME}`}
          ref={rowRef}
          onClick={handleRowClick}
        >
          <Box
            className={`${classes.content} ${classes.name}`}
            sx={{ transform: `translateX(${depth * 24}px)` }}
          >
            {icon}
            {resource.name}
          </Box>
          <span className={classes.content}>{resource.packageName}</span>
          <span className={classes.content}>{resource.type}</span>
        </div>
        {nextData.length > 0 ? (
          nextData.map((data, idx) => (
            <DependencyAnalysisContentsRow
              key={`dependency-analysis-contents-collapse-${idx}`}
              resource={data}
              id={data.id}
              depth={depth + 1}
              setAlert={setAlert}
            />
          ))
        ) : (
          <></>
        )}
      </>
    );
  }
);

export default DependencyAnalysisContentsRow;
