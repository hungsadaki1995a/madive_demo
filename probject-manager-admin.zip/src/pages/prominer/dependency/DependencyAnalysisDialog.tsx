import { Dispatch, SetStateAction } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Dialog,
  DialogTitle,
  Divider,
  DialogContent,
  DialogActions,
  Button,
} from '@mui/material';
import makeStyles from '@mui/styles/makeStyles';

const useStyles = makeStyles(() => ({
  dialog: {
    '& .MuiDialog-container': {
      minWidth: 695,
    },
  },
  dialogTitle: {
    '& h2': {
      fontSize: 16,
      fontWeight: 600,
      color: '#444',
    },
  },
  divider: {
    margin: '0px 20px',
  },
  dialogContent: {
    overflowX: 'hidden',
    '& p': {
      display: 'flex',
      alignItems: 'center',
      width: 175,
      fontSize: 14,
      margin: 0,
    },
    '& input': {
      padding: '5px 10px',
      width: 312,
      fontSize: 14,
      color: '#555',
    },
    '& input[type=radio]': {
      width: 'fit-content',
    },
    '& .Mui-disabled[type=text]': {
      backgroundColor: 'rgba(0, 0, 0, 0.1)',
    },
    '& .Mui-disabled[role=button]': {
      backgroundColor: 'rgba(0, 0, 0, 0.1)',
    },
  },
  dialogDelete: {
    padding: 80,
  },
}));

interface propsType {
  openDialog: boolean;
  setOpenDialog: Dispatch<SetStateAction<boolean>>;
}

const DependencyAnalysisDialog = ({ openDialog, setOpenDialog }: propsType) => {
  const classes = useStyles();
  const navigate = useNavigate();

  const handleSubmitDialog = () => {
    sessionStorage.removeItem('dependencyId');
    navigate('/development/prominer/dependency');
    handleCloseDialog();
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
  };

  return (
    <Dialog
      className={classes.dialog}
      maxWidth="md"
      open={openDialog}
      onClose={handleCloseDialog}
      aria-labelledby="form-dialog-title"
    >
      <DialogTitle className={classes.dialogTitle} id="form-dialog-title">
        New Analysis
      </DialogTitle>
      <Divider className={classes.divider} />
      <DialogContent className={classes.dialogDelete}>
        Are you sure to start a new analysis?
      </DialogContent>
      <DialogActions>
        <Button
          onClick={handleSubmitDialog}
          color="primary"
          variant="contained"
        >
          OK
        </Button>
        <Button color="inherit" onClick={handleCloseDialog} variant="contained">
          Cancel
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default DependencyAnalysisDialog;
