import React, { SetStateAction, Dispatch } from 'react';
import {
  TextField,
  Select,
  SelectChangeEvent,
  MenuItem,
  DialogContentText,
  Radio,
  RadioGroup,
  FormControlLabel,
} from '@mui/material';
import makeStyles from '@mui/styles/makeStyles';
import { useStore } from '@/utils';
import { nodesType } from '@/types/typeBundle';

const useStyles = makeStyles(() => ({
  dialogTitle: {
    '& h2': {
      fontSize: 16,
      fontWeight: 600,
      color: '#444',
    },
  },
  dialogBox: {
    display: 'flex',
    margin: '12px 35px',
  },
  dialogSelect: {
    width: 150,
    fontSize: 14,
    '& div': {
      padding: '5px 10px',
    },
  },
  radioGroup: {
    width: 312,
    '& span': {
      fontSize: 14,
    },
  },
}));

interface RowPropsType {
  selectedAction: { action: string; nodeKey: string };
  nodeValue: nodesType;
  setNodeValue: Dispatch<SetStateAction<nodesType>>;
  title: string;
  name: string;
  value: string | boolean;
}

export const DialogTextRow = ({
  selectedAction,
  nodeValue,
  setNodeValue,
  title,
  name,
  value,
}: RowPropsType) => {
  const classes = useStyles();
  const disableDelete = selectedAction.action === 'Delete';
  const disableEdit =
    selectedAction.action === 'Edit' &&
    (title === 'Node Name*' || title === 'Server Host Name*');

  const handleTextChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const target = e.target;
    setNodeValue({ ...nodeValue, [target.name]: target.value });
  };

  return (
    <div className={classes.dialogBox}>
      <DialogContentText className={classes.dialogTitle}>
        {title}
      </DialogContentText>
      <TextField
        name={name}
        value={value || ''}
        disabled={disableDelete || disableEdit}
        autoComplete="off"
        onChange={handleTextChange}
        spellCheck="false"
      />
    </div>
  );
};

export const DialogSelectRow = ({
  selectedAction,
  nodeValue,
  setNodeValue,
  title,
  name,
  value,
}: RowPropsType) => {
  const classes = useStyles();
  const { NodeStore } = useStore();
  const disableDelete = selectedAction.action === 'Delete';
  const disabledExceptMaster =
    title === 'Master Node Key' && nodeValue.nodeType === 'MASTER';
  const selectItems: { [key: string]: string[] } = {
    nodeType: ['TEST', 'RUNTIME', 'MASTER'],
    masterNodeKey: NodeStore.masterNodes
      .map((node: nodesType) => {
        return node.nodeKey;
      })
      .filter((nodeKey: string) => {
        return nodeValue.nodeKey !== nodeKey;
      }),
  };

  const handleSelectChange = (
    e: SelectChangeEvent<{ value: string | unknown }>
  ) => {
    title === 'Node Type*'
      ? setNodeValue({
          ...nodeValue,
          [e.target.name]: e.target.value as string,
          masterNodeKey: '',
        })
      : setNodeValue({
          ...nodeValue,
          [e.target.name]: e.target.value as string,
        });
  };

  return (
    <div className={classes.dialogBox}>
      <DialogContentText className={classes.dialogTitle}>
        {title === 'Master Node Key' && !disabledExceptMaster
          ? title + '*'
          : title}
      </DialogContentText>
      <Select
        id={name}
        name={name}
        disabled={disableDelete || disabledExceptMaster}
        value={(value as any) || ''}
        className={classes.dialogSelect}
        onChange={handleSelectChange}
        MenuProps={{
          anchorOrigin: {
            vertical: 'bottom',
            horizontal: 'left',
          },
          transformOrigin: {
            vertical: -3,
            horizontal: 0,
          },
        }}
      >
        {selectItems[name] ? (
          selectItems[name].map((item, idx) => {
            return (
              <MenuItem value={item} key={`menu-item-${idx}`}>
                {item}
              </MenuItem>
            );
          })
        ) : (
          <MenuItem value="">No Option Available</MenuItem>
        )}
      </Select>
    </div>
  );
};

export const DialogBooleanRow = ({
  selectedAction,
  nodeValue,
  setNodeValue,
  title,
  name,
  value,
}: RowPropsType) => {
  const classes = useStyles();
  const disabled = selectedAction.action === 'Delete';
  const radioItems: { [key: string]: string[] } = {
    nodeIsSsl: ['true', 'false'],
  };

  const handleRadioChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = radioItems[e.target.name].indexOf(e.target.value) === 0;
    setNodeValue({ ...nodeValue, [e.target.name]: value ? 'Y' : 'N' });
  };

  return (
    <div className={classes.dialogBox}>
      <DialogContentText className={classes.dialogTitle}>
        {title}
      </DialogContentText>
      <RadioGroup
        row
        className={classes.radioGroup}
        defaultValue={radioItems[name][1]}
        value={radioItems[name][value === 'Y' ? 0 : 1]}
      >
        {radioItems[name].map((item, idx) => {
          return (
            <FormControlLabel
              disabled={disabled}
              key={`radio-item-${idx}`}
              value={item}
              control={<Radio name={name} onChange={handleRadioChange} />}
              label={item}
            />
          );
        })}
      </RadioGroup>
    </div>
  );
};
