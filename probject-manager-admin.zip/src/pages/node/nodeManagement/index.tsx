import { Routes, Route, Navigate } from 'react-router-dom';
import NodeManagement from '@/pages/node/nodeManagement/NodeManagement';
import { subMenusType } from '@/types/typeBundle';
import Error from '@/pages/error';

const Node = ({ subMenus }: { subMenus: subMenusType[] }) => {
  return (
    <Routes>
      <Route
        path="/management"
        element={<NodeManagement title={subMenus[0].title} />}
      />
      <Route
        path="/"
        element={<Navigate to="/development/node/management" />}
      />
      <Route path="/*" element={<Error />} />
    </Routes>
  );
};

export default Node;
