import { useState, Dispatch, SetStateAction, useEffect } from 'react';
import {
  Dialog,
  DialogTitle,
  Divider,
  DialogContent,
  Button,
  DialogActions,
} from '@mui/material';
import makeStyles from '@mui/styles/makeStyles';
import {
  DialogTextRow,
  DialogSelectRow,
  DialogBooleanRow,
} from './NodeManagementHeaderDialogRow';
import useStore from '@/utils/useStore';
import { NodeApi } from '@/apis';
import { nodesType } from '@/types/typeBundle';

const useStyles = makeStyles(() => ({
  dialog: {
    '& .MuiDialog-container': {
      minWidth: 695,
    },
  },
  dialogTitle: {
    '& h2': {
      fontSize: 16,
      fontWeight: 600,
      color: '#444',
    },
  },
  divider: {
    margin: '0px 20px',
  },
  dialogContent: {
    overflowX: 'hidden',
    '& p': {
      display: 'flex',
      alignItems: 'center',
      width: 175,
      fontSize: 14,
      margin: 0,
    },
    '& input': {
      padding: '5px 10px',
      width: 312,
      fontSize: 14,
      color: '#555',
    },
    '& input[type=radio]': {
      width: 'fit-content',
    },
    '& .Mui-disabled[type=text]': {
      backgroundColor: 'rgba(0, 0, 0, 0.1)',
    },
    '& .Mui-disabled[role=button]': {
      backgroundColor: 'rgba(0, 0, 0, 0.1)',
    },
  },
  dialogDelete: {
    padding: 50,
  },
}));

interface dialogPropsType {
  openDialog: boolean;
  selectedAction: { action: string; nodeKey: string };
  setSelectedAction: Dispatch<
    SetStateAction<{ action: string; nodeKey: string }>
  >;
  setOpenDialog: Dispatch<SetStateAction<boolean>>;
  initializeData: () => void;
  setAlert: (severity: 'success' | 'error', message: string) => void;
}

const NodeManagementHeaderDialog = ({
  openDialog,
  selectedAction,
  setSelectedAction,
  setOpenDialog,
  initializeData,
  setAlert,
}: dialogPropsType) => {
  const initialNodeValue = {
    description: '',
    nodeKey: '',
    nodeType: '',
    nodeName: '',
    nodeIp: '',
    nodeBasePort: '',
    nodeHttpPort: '',
    masterNodeKey: '',
    nodeIsSsl: 'N',
    serverHostName: '',
  };
  const [nodeValue, setNodeValue] = useState<nodesType>(initialNodeValue);
  const { NodeStore } = useStore();
  const classes = useStyles();

  const checkSubmitValue = () => {
    const TITLES: { [key: string]: string } = {
      nodeName: 'Node Name',
      nodeIp: 'IP',
      nodeBasePort: 'Base Port',
      nodeHttpPort: 'Http Port',
      serverHostName: 'Server Host Name',
      nodeType: 'Node Type',
      masterNodeKey: 'Master Node Key',
    };
    const emptyStrings: string[] = Object.entries(TITLES)
      .filter((title) => {
        if (title[0] === 'masterNodeKey' && nodeValue.nodeType === 'MASTER')
          return false;
        return (
          (nodeValue as unknown as { [key: string]: string })[title[0]] === ''
        );
      })
      .map((title) => {
        return title[1];
      });
    if (emptyStrings.length > 0) {
      setAlert(
        'error',
        `Please enter values for the following: ${emptyStrings.join(', ')}`
      );
      return false;
    }
    const repeatedNodes = NodeStore.nodes.filter((node: nodesType) => {
      return (
        nodeValue.nodeKey === node.nodeKey &&
        nodeValue.serverHostName === node.serverHostName
      );
    });
    if (repeatedNodes.length > 0 && selectedAction.action !== 'Edit') {
      setAlert(
        'error',
        'A node with the same Node Name and Server Host Name already exists.'
      );
      return false;
    }
    return true;
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
    setTimeout(() => {
      setNodeValue({ ...initialNodeValue });
      setSelectedAction({ action: 'Create', nodeKey: '' });
    }, 200);
  };

  const checkResponse = (response: object) => {
    if ((response as { data: { success: boolean } }).data?.success) {
      handleCloseDialog();
      initializeData();
      setAlert('success', 'The request was successfully done.');
    } else {
      setAlert(
        'error',
        `Request failed: ${
          (response as { data: { errorMsg: string } }).data?.errorMsg
        }`
      );
    }
  };

  const handleSubmitDialog = async () => {
    if (selectedAction.action === 'Delete') {
      const submitValue = NodeStore.nodes
        .filter((node: nodesType) => {
          return NodeStore.selectedNodes.includes(node.nodeKey);
        })
        .map((node: nodesType) => {
          return {
            serverHostName: node.serverHostName,
            nodeName: node.nodeName,
          };
        });
      checkResponse((await NodeApi.delete(submitValue)) as object);
      return;
    }
    if (checkSubmitValue()) {
      const response =
        selectedAction.action === 'Create'
          ? await NodeApi.add(nodeValue)
          : await NodeApi.edit(nodeValue);
      checkResponse(response as object);
    }
  };

  const handleSelectedAction = async () => {
    const targetNode = NodeStore.nodes.find((node: nodesType) => {
      return selectedAction.nodeKey === node.nodeKey;
    });
    if (targetNode && targetNode.length === 0) {
      setAlert('error', 'There is no such node data.');
      return;
    }
    setNodeValue(targetNode ? targetNode : initialNodeValue);
    setOpenDialog(true);
  };

  useEffect(() => {
    if (selectedAction.action === 'Create') return;
    handleSelectedAction();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedAction]);

  return (
    <Dialog
      className={classes.dialog}
      maxWidth="md"
      open={openDialog}
      onClose={handleCloseDialog}
      aria-labelledby="form-dialog-title"
    >
      {selectedAction.action === 'Delete' ? (
        <>
          <DialogTitle className={classes.dialogTitle} id="form-dialog-title">
            Delete Node
          </DialogTitle>
          <Divider className={classes.divider} />
          <DialogContent className={classes.dialogDelete}>
            Are you sure to delete all checked nodes?
          </DialogContent>
          <DialogActions>
            <Button
              onClick={handleSubmitDialog}
              color="primary"
              variant="contained"
            >
              OK
            </Button>
            <Button
              color="inherit"
              onClick={handleCloseDialog}
              variant="contained"
            >
              Cancel
            </Button>
          </DialogActions>
        </>
      ) : (
        <>
          <DialogTitle className={classes.dialogTitle}>{`${
            selectedAction.action === 'Create'
              ? 'Create New'
              : selectedAction.action
          } Data`}</DialogTitle>
          <Divider className={classes.divider} />
          <DialogContent className={classes.dialogContent}>
            <DialogTextRow
              selectedAction={selectedAction}
              nodeValue={nodeValue}
              setNodeValue={setNodeValue}
              title="Node Name*"
              name="nodeName"
              value={nodeValue.nodeName}
            />
            <DialogTextRow
              selectedAction={selectedAction}
              nodeValue={nodeValue}
              setNodeValue={setNodeValue}
              title="IP*"
              name="nodeIp"
              value={nodeValue.nodeIp}
            />
            <DialogTextRow
              selectedAction={selectedAction}
              nodeValue={nodeValue}
              setNodeValue={setNodeValue}
              title="Base Port*"
              name="nodeBasePort"
              value={nodeValue.nodeBasePort}
            />
            <DialogTextRow
              selectedAction={selectedAction}
              nodeValue={nodeValue}
              setNodeValue={setNodeValue}
              title="Http Port*"
              name="nodeHttpPort"
              value={nodeValue.nodeHttpPort}
            />
            <DialogTextRow
              selectedAction={selectedAction}
              nodeValue={nodeValue}
              setNodeValue={setNodeValue}
              title="Server Host Name*"
              name="serverHostName"
              value={nodeValue.serverHostName}
            />
            <DialogBooleanRow
              selectedAction={selectedAction}
              nodeValue={nodeValue}
              setNodeValue={setNodeValue}
              title="SSL*"
              name="nodeIsSsl"
              value={nodeValue.nodeIsSsl}
            />
            <DialogSelectRow
              selectedAction={selectedAction}
              nodeValue={nodeValue}
              setNodeValue={setNodeValue}
              title="Node Type*"
              name="nodeType"
              value={nodeValue.nodeType}
            />
            <DialogSelectRow
              selectedAction={selectedAction}
              nodeValue={nodeValue}
              setNodeValue={setNodeValue}
              title="Master Node Key"
              name="masterNodeKey"
              value={nodeValue.masterNodeKey}
            />
            <DialogTextRow
              selectedAction={selectedAction}
              nodeValue={nodeValue}
              setNodeValue={setNodeValue}
              title="Description"
              name="description"
              value={nodeValue.description}
            />
          </DialogContent>
          <DialogActions>
            <Button
              onClick={handleSubmitDialog}
              color="primary"
              variant="contained"
            >
              {selectedAction.action}
            </Button>
            <Button
              color="inherit"
              onClick={handleCloseDialog}
              variant="contained"
            >
              Cancel
            </Button>
          </DialogActions>
        </>
      )}
    </Dialog>
  );
};

export default NodeManagementHeaderDialog;
