import React, { useState, useRef, Dispatch, SetStateAction } from 'react';
import { observer } from 'mobx-react';
import { Select, SelectChangeEvent, MenuItem, IconButton } from '@mui/material';
import makeStyles from '@mui/styles/makeStyles';
import NodeManagementHeaderDialog from './NodeManagementHeaderDialog';
import AddIcon from '@mui/icons-material/Add';
import SearchIcon from '@mui/icons-material/Search';
import { useStore } from '@/utils';
import { nodesType } from '@/types/typeBundle';

const useStyles = makeStyles(() => ({
  create: {
    display: 'flex',
    alignItems: 'center',
    border: '1px solid #0175bc',
    padding: 5,
    color: '#0175bc',
    fontSize: 14,
    cursor: 'pointer',
    '& svg': {
      color: '#0175bc',
    },
  },
  select: {
    paddingLeft: 12,
    width: 175,
    fontSize: 14,
    '& div': {
      padding: '5px 0',
    },
  },
  search: {
    display: 'flex',
  },
  searchText: {
    display: 'flex',
    alignItems: 'center',
    border: '1px solid #dbdbdb',
    paddingLeft: 12,
    marginLeft: 10,
    width: 225,
    height: 30,
    fontSize: 14,
  },
  searchInput: {
    border: 'none',
    outline: 'none',
    flexGrow: 1,
  },
  searchButton: {
    padding: 3,
  },
}));

interface propsType {
  initializeData: () => void;
  selectedAction: { action: string; nodeKey: string };
  setSelectedAction: Dispatch<
    SetStateAction<{ action: string; nodeKey: string }>
  >;
  sortDataByType: () => nodesType[];
  setNodeData: Dispatch<SetStateAction<nodesType[]>>;
  orderNode: (
    node: nodesType[],
    order: 'asc' | 'desc',
    field: keyof nodesType
  ) => nodesType[];
  setAlert: (severity: 'success' | 'error', message: string) => void;
}

const NodeManagementHeader = observer(
  ({
    initializeData,
    selectedAction,
    setSelectedAction,
    sortDataByType,
    setNodeData,
    orderNode,
    setAlert,
  }: propsType) => {
    const [openDialog, setOpenDialog] = useState(false);
    const searchRef = useRef<HTMLInputElement>(null);
    const classes = useStyles();
    const { NodeStore } = useStore();
    const TITLE = 'Create New Node';
    const MENU_ITEMS: { [key: string]: string } = {
      'Node Name': 'nodeName',
      IP: 'nodeIp',
      'Base Port': 'nodeBasePort',
      'Http Port': 'nodeHttpPort',
      'Server Host Name': 'serverHostName',
      SSL: 'nodeIsSsl',
      'Node Type': 'nodeType',
    };

    const handleCreateClick = () => {
      setOpenDialog(true);
    };

    const handleSelectChange = (
      e: SelectChangeEvent<{ value: string | unknown }>
    ) => {
      NodeStore.setSearchType(e.target.value);
    };

    const handleIconClick = () => {
      NodeStore.setSearchText(searchRef?.current?.value || '');
      const newData = sortDataByType().filter((data: nodesType) => {
        if (!searchRef.current) return false;
        if (
          !(data as unknown as { [key: string]: string })[
            MENU_ITEMS[NodeStore.searchType]
          ]
        )
          return NodeStore.searchText === '' ? true : false;
        return (data as unknown as { [key: string]: string })[
          MENU_ITEMS[NodeStore.searchType]
        ].includes(NodeStore.searchText);
      });
      NodeStore.setSelectedNodes([]);
      setNodeData(orderNode(newData, NodeStore.order, NodeStore.orderProperty));
    };

    const handleSubmitByEnter = (e: React.KeyboardEvent) => {
      if (e.key === 'Enter') {
        handleIconClick();
      }
    };

    return (
      <>
        <div className={classes.create} onClick={handleCreateClick}>
          <AddIcon />
          {TITLE}
        </div>
        <NodeManagementHeaderDialog
          openDialog={openDialog}
          selectedAction={selectedAction}
          setSelectedAction={setSelectedAction}
          setOpenDialog={setOpenDialog}
          initializeData={initializeData}
          setAlert={setAlert}
        />
        <div className={classes.search}>
          <Select
            className={classes.select}
            value={NodeStore.searchType as any}
            onChange={handleSelectChange}
            MenuProps={{
              anchorOrigin: {
                vertical: 'bottom',
                horizontal: 'left',
              },
              transformOrigin: {
                vertical: -5,
                horizontal: 8,
              },
            }}
          >
            {Object.keys(MENU_ITEMS).map((item: string, idx: number) => {
              return (
                <MenuItem
                  key={`node-management-header-select-${idx}`}
                  value={item}
                >
                  {item}
                </MenuItem>
              );
            })}
          </Select>
          <div className={classes.searchText}>
            <input
              className={classes.searchInput}
              type="text"
              ref={searchRef}
              onKeyDown={handleSubmitByEnter}
            ></input>
            <IconButton
              aria-label="search-button"
              className={classes.searchButton}
              onClick={handleIconClick}
              size="large"
            >
              <SearchIcon />
            </IconButton>
          </div>
        </div>
      </>
    );
  }
);

export default NodeManagementHeader;
