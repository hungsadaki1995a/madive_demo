import {
  useState,
  useEffect,
  useCallback,
  Dispatch,
  SetStateAction,
} from 'react';
import { observer } from 'mobx-react';
import {
  Table,
  TableHead,
  TableBody,
  TableCell,
  TableContainer,
  TablePagination,
  TableRow,
  TableSortLabel,
} from '@mui/material';
import makeStyles from '@mui/styles/makeStyles';
import { useStore } from '@/utils';
import CheckBox from '@mui/material/Checkbox';
import {
  nodesSelectionType,
  nodesType,
  paginationType,
} from '@/types/typeBundle';
import { TableBodyContents, TableEmpty } from '@/components/molecules';

const useStyles = makeStyles(() => ({
  select: {
    fontSize: 12,
    fontWeight: 450,
    color: '#000',
  },
  inputSelect: {
    display: 'flex',
    alignItems: 'center',
    '& div': {
      left: -40,
      padding: 0,
      margin: 0,
      width: 100,
    },
    '& div div': {
      padding: '5px 0',
    },
    '& label:hover': {
      color: 'rgba(0, 0, 0, 0.54)',
      fontWeight: 400,
    },
    '& .Mui-focused': {
      color: '#888',
    },
  },
  pagination: {
    position: 'fixed',
    bottom: 20,
    borderBottom: 'none',
    minWidth: 1330,
    width: 'calc(100vw - 310px)',
    '& div p, div div': {
      fontSize: '0.875rem',
      color: '#000',
    },
  },
  checkboxContainer: {
    width: 24,
  },
  emptyHeader: {
    display: 'none',
  },
}));

interface tableProps {
  nodeData: nodesType[];
  pagination: paginationType;
  setPagination: Dispatch<SetStateAction<paginationType>>;
}

const NodeManagementTable = observer(
  ({ nodeData, pagination, setPagination }: tableProps) => {
    const [data, setData] = useState<nodesSelectionType[]>([]);
    const classes = useStyles();
    const { NodeStore } = useStore();
    const columns = [
      { title: 'Selection', field: 'selection' },
      { title: 'Node Name', field: 'nodeName' },
      { title: 'IP', field: 'nodeIp' },
      { title: 'Base Port', field: 'nodeBasePort' },
      { title: 'Http Port', field: 'nodeHttpPort' },
      { title: 'Server Host Name', field: 'serverHostName' },
      { title: 'SSL', field: 'nodeIsSsl' },
      { title: 'Node Type', field: 'nodeType' },
      { title: 'Description', field: 'description' },
    ];

    const orderTable = (
      node: nodesSelectionType[],
      order: 'asc' | 'desc',
      field: keyof nodesSelectionType
    ) => {
      return node.sort((a, b) => {
        if (a[field] === null) return order === 'asc' ? -1 : 1;
        if (b[field] === null) return order === 'asc' ? 1 : -1;
        let thisOrder = 0;
        String(Number(a[field])) === a[field] &&
        String(Number(b[field])) === b[field]
          ? (thisOrder =
              Number(a[field]) > Number(b[field])
                ? 1
                : Number(a[field]) < Number(b[field])
                ? -1
                : 0)
          : (thisOrder =
              a[field] > b[field] ? 1 : a[field] < b[field] ? -1 : 0);
        return order === 'asc' ? thisOrder : thisOrder * -1;
      });
    };

    const handleOrderTable = (field: keyof nodesSelectionType) => {
      const newOrder =
        field === NodeStore.orderProperty
          ? NodeStore.order === 'asc'
            ? 'desc'
            : 'asc'
          : 'asc';
      NodeStore.setOrderProperty(field);
      NodeStore.setOrder(newOrder);
      setData(orderTable(data, NodeStore.order, NodeStore.orderProperty));
    };

    const handlePageChange = async (
      e: React.MouseEvent | null,
      page: number
    ) => {
      setPagination({ ...pagination, page: page });
    };

    const handleRowsPerPageChange = async (e: React.ChangeEvent) => {
      const newPageSize = Number((e.target as HTMLInputElement).value);
      setPagination({ ...pagination, pageSize: newPageSize });
      setData(orderTable(data, NodeStore.order, NodeStore.orderProperty));
    };

    const handleHeaderCheckboxChange = () => {
      const allDataChecked = NodeStore.selectedNodes.length === data.length;
      const newSelectedData = !allDataChecked
        ? data.map((node) => {
            return node.nodeKey;
          })
        : [];
      NodeStore.setSelectedNodes(newSelectedData);
      setData(orderTable(data, NodeStore.order, NodeStore.orderProperty));
    };

    const setNewData = useCallback(() => {
      const handleBodyCheckboxClick = (node: nodesType) => {
        const newSelectedData = NodeStore.selectedNodes.includes(node.nodeKey)
          ? NodeStore.selectedNodes.filter((nodeKey: string) => {
              return nodeKey !== node.nodeKey;
            })
          : [...NodeStore.selectedNodes, node.nodeKey];
        NodeStore.setSelectedNodes(newSelectedData);
      };
      const newData = nodeData
        .filter((_, idx) => {
          return (
            idx >= pagination.page * pagination.pageSize &&
            idx < (pagination.page + 1) * pagination.pageSize
          );
        })
        .map((node) => {
          return {
            ...node,
            selection: (
              <CheckBox
                color="info"
                checked={NodeStore.selectedNodes.includes(node.nodeKey)}
                onClick={() => handleBodyCheckboxClick(node)}
              />
            ),
          };
        });
      setData(orderTable(newData, NodeStore.order, NodeStore.orderProperty));
    }, [NodeStore, nodeData, pagination.page, pagination.pageSize]);

    useEffect(() => {
      setNewData();
    }, [setNewData, NodeStore.selectedNodes]);

    return (
      <TableContainer>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell className={classes.checkboxContainer}>
                <CheckBox
                  color="info"
                  checked={
                    NodeStore.selectedNodes.length !== 0 &&
                    NodeStore.selectedNodes.length === data.length
                  }
                  onChange={handleHeaderCheckboxChange}
                />
              </TableCell>
              {columns.map((column, idx) => {
                return column.field === 'selection' ? (
                  <td
                    key={`node-head-${idx}`}
                    className={classes.emptyHeader}
                  ></td>
                ) : (
                  <TableCell key={`node-head-${idx}`}>
                    <TableSortLabel
                      active={NodeStore.orderProperty === column.field}
                      direction={
                        NodeStore.orderProperty === column.field
                          ? NodeStore.order
                          : 'asc'
                      }
                      onClick={() =>
                        handleOrderTable(
                          column.field as keyof nodesSelectionType
                        )
                      }
                    >
                      {column.title}
                    </TableSortLabel>
                  </TableCell>
                );
              })}
            </TableRow>
          </TableHead>
          <TableBody>
            {data.length === 0 ? (
              <TableEmpty />
            ) : (
              <TableBodyContents data={data} columns={columns} />
            )}
            <TableRow>
              <TablePagination
                className={classes.pagination}
                rowsPerPageOptions={[10, 25, 50]}
                count={pagination.totalCount}
                rowsPerPage={pagination.pageSize}
                page={pagination.page}
                onPageChange={handlePageChange}
                onRowsPerPageChange={handleRowsPerPageChange}
              />
            </TableRow>
          </TableBody>
        </Table>
      </TableContainer>
    );
  }
);

export default NodeManagementTable;
