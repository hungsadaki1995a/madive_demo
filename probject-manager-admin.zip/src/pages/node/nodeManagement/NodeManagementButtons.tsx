import { Dispatch, SetStateAction } from 'react';
import { useStore } from '@/utils';
import makeStyles from '@mui/styles/makeStyles';

const useStyles = makeStyles(() => ({
  wrap: {
    display: 'flex',
  },
  button: {
    border: 'none',
    borderRadius: 0,
    padding: '5px 0',
    margin: '0 10px',
    width: 90,
    height: 35,
    color: '#fff',
    backgroundColor: '#4085ee',
    cursor: 'pointer',
  },
}));

interface propsType {
  disabledButtons: { change: boolean; delete: boolean };
  setSelectedAction: Dispatch<
    SetStateAction<{ action: string; nodeKey: string }>
  >;
  setAlert: (severity: 'success' | 'error', message: string) => void;
}

const NodeManagementButtons = ({
  disabledButtons,
  setSelectedAction,
  setAlert,
}: propsType) => {
  const classes = useStyles();
  const { NodeStore } = useStore();

  const handleClickChange = () => {
    if (NodeStore.selectedNodes.length !== 1) {
      setAlert('error', 'The length of selected data should be 1.');
      return;
    }
    setSelectedAction({ action: 'Edit', nodeKey: NodeStore.selectedNodes[0] });
  };

  const handleClickDelete = () => {
    if (NodeStore.selectedNodes.length === 0) {
      setAlert('error', 'There is no data selected.');
      return;
    }
    setSelectedAction({ action: 'Delete', nodeKey: '' });
  };

  return (
    <div className={classes.wrap}>
      <button
        className={classes.button}
        disabled={disabledButtons.change}
        onClick={handleClickChange}
      >
        Change
      </button>
      <button
        className={classes.button}
        disabled={disabledButtons.delete}
        onClick={handleClickDelete}
      >
        Delete
      </button>
    </div>
  );
};

export default NodeManagementButtons;
