import { useState, useEffect } from 'react';
import { observer } from 'mobx-react';
import { Select, SelectChangeEvent, MenuItem } from '@mui/material';
import makeStyles from '@mui/styles/makeStyles';
import NodeManagementTable from './NodeManagementTable';
import NodeManagementHeader from './NodeManagementHeader';
import NodeManagementButtons from './NodeManagementButtons';
import { useStore } from '@/utils';
import { NodeApi } from '@/apis';
import { selectedType, nodesType, paginationType } from '@/types/typeBundle';

const useStyles = makeStyles(() => ({
  wrap: {
    width: 'calc(100vw - 240px)',
    height: 'calc(100vh - 50px)',
  },
  title: {
    padding: 13,
    minWidth: 200,
    color: 'rgb(39, 111, 195)',
  },
  contents: {
    padding: 20,
    width: 'calc(100vw - 280px)',
    minWidth: 1360,
    height: 'calc(100vh - 135px)',
    minHeight: 750,
    backgroundColor: '#E8EDF1',
  },
  contentsWrap: {
    width: '100%',
    height: '100%',
    backgroundColor: '#fff',
  },
  select: {
    borderBottom: '1px solid #dbdbdb',
    padding: 10,
    width: 'calc(100% - 20px)',
    '& div': {
      padding: '5px 10px',
      width: 225,
      fontSize: 14,
    },
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '10px 10px 5px',
  },
  table: {
    padding: 12,
    maxHeight: 580,
    overflowY: 'auto',
    '& table': {
      tableLayout: 'fixed',
    },
    '& div': {
      boxShadow: 'none',
    },
    '& thead tr': {
      position: 'sticky',
      top: 0,
      zIndex: 1,
    },
    '& thead tr th': {
      fontSize: 12,
      fontWeight: 600,
      backgroundColor: '#f4f7fc',
      whiteSpace: 'nowrap',
      padding: 12,
      '& span': {
        padding: 0,
      },
    },
    '& tbody': {
      padding: '0 16px',
      backgroundColor: '#fff',
      '& tr:hover': {
        backgroundColor: '#e6f4ff',
        '& td': {
          fontWeight: 600,
          color: '#000',
        },
      },
      '& td': {
        padding: 12,
        fontSize: 12,
        whiteSpace: 'nowrap',
        fontWeight: 450,
        color: '#888',
        '& span': {
          padding: 0,
        },
      },
    },
  },
  buttons: {
    position: 'fixed',
    bottom: 30,
    padding: '10px 10px 5px',
    '& :disabled': {
      backgroundColor: '#000',
      cursor: 'not-allowed',
    },
  },
}));

const NodeManagement = observer(({ title }: { title: string }) => {
  const [pagination, setPagination] = useState<paginationType>({
    page: 0,
    pageSize: 10,
    totalCount: 0,
  });
  const [selectedType, setSelectedType] = useState<selectedType>('ALL');
  const [selectedAction, setSelectedAction] = useState<{
    action: string;
    nodeKey: string;
  }>({ action: 'Create', nodeKey: '' });
  const [nodeData, setNodeData] = useState<nodesType[]>([]);
  const [disabledButtons, setDisabledButtons] = useState<{
    change: boolean;
    delete: boolean;
  }>({ change: true, delete: true });
  const classes = useStyles();
  const { NodeStore, AlertStore } = useStore();
  const TYPE_MENU_ITEMS: selectedType[] = ['ALL', 'TEST', 'RUNTIME', 'MASTER'];
  const MENU_ITEMS: { [key: string]: string } = {
    'Node Name': 'nodeName',
    IP: 'nodeIp',
    'Base Port': 'nodeBasePort',
    'Http Port': 'nodeHttpPort',
    'Server Host Name': 'serverHostName',
    SSL: 'nodeIsSsl',
    'Node Type': 'nodeType',
  };
  const STATUS = { isFetching: false };

  const handleSelectChange = (
    e: SelectChangeEvent<{ value: selectedType | unknown }>
  ) => {
    setSelectedType(e.target.value as selectedType);
  };

  const setAlert = async (severity: 'error' | 'success', message: string) => {
    AlertStore.openApiAlert(severity, message);
  };

  const orderNode = (
    node: nodesType[],
    order: 'asc' | 'desc',
    field: keyof nodesType
  ) => {
    const thisOrder = order === 'asc' ? 1 : -1;
    return node.sort((a, b) => {
      const newOrder =
        String(a[field]) > String(b[field])
          ? 1
          : String(a[field]) < String(b[field])
          ? -1
          : 0;
      return newOrder * thisOrder;
    });
  };

  // const initializeData = async () => {
  //   STATUS.isFetching = true;
  //   const data = await NodeApi.get('');
  //   NodeStore.setSelectedNodes([]);
  //   if (data.success) {
  //     NodeStore.setNodes([...(data.poDeployNodeDTOArray || [])]);
  //     NodeStore.setSelectedNodes([]);
  //     const newNode = sortDataByType().filter((data: nodesType) => {
  //       if (
  //         !(data as unknown as { [key: string]: string })[
  //           MENU_ITEMS[NodeStore.searchType]
  //         ]
  //       )
  //         return NodeStore.searchText === '' ? true : false;
  //       return (data as unknown as { [key: string]: string })[
  //         MENU_ITEMS[NodeStore.searchType]
  //       ].includes(NodeStore.searchText);
  //     });
  //     setNodeData(orderNode(newNode, NodeStore.order, NodeStore.orderProperty));
  //     setPagination({
  //       ...pagination,
  //       totalCount: data.poDeployNodeDTOArray.length,
  //     });
  //   }
  //   STATUS.isFetching = false;
  // };

  const initializeData = async () => {
    STATUS.isFetching = true;
    const data = await NodeApi.get('');
    NodeStore.setSelectedNodes([]);
    if (data) {
      console.log(`${JSON.stringify(data.dto.NodeDto)}`);
      NodeStore.setNodes([...(data.dto.NodeDto || [])]);
      NodeStore.setSelectedNodes([]);
      const newNode = sortDataByType().filter((data: nodesType) => {
        if (
          !(data as unknown as { [key: string]: string })[
            MENU_ITEMS[NodeStore.searchType]
          ]
        )
          return NodeStore.searchText === '' ? true : false;
        return (data as unknown as { [key: string]: string })[
          MENU_ITEMS[NodeStore.searchType]
        ].includes(NodeStore.searchText);
      });
      setNodeData(orderNode(newNode, NodeStore.order, NodeStore.orderProperty));
      setPagination({
        ...pagination,
        totalCount: data.dto.NodeDto.length,
      });
    }
    STATUS.isFetching = false;
  };

  const sortDataByType = () => {
    const allNodes = [...NodeStore.nodes];
    const newNodes: nodesType[] =
      selectedType === 'ALL'
        ? allNodes
        : allNodes.filter((node: nodesType) => {
            return node.nodeType === selectedType;
          });
    return newNodes;
  };

  const setDataByType = () => {
    setNodeData(sortDataByType());
  };

  useEffect(() => {
    if (STATUS.isFetching) return;
    NodeStore.setSearchType('Node Name');
    NodeStore.setSearchText('');
    NodeStore.setOrder('asc');
    NodeStore.setOrderProperty('nodeName');
    initializeData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    setDataByType();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedType]);

  useEffect(() => {
    setPagination({ ...pagination, page: 0, totalCount: nodeData.length });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [nodeData]);

  useEffect(() => {
    if (NodeStore.selectedNodes.length === 0) {
      setDisabledButtons({ change: true, delete: true });
    } else if (NodeStore.selectedNodes.length === 1) {
      setDisabledButtons({ change: false, delete: false });
    } else {
      setDisabledButtons({ change: true, delete: false });
    }
  }, [NodeStore.selectedNodes]);

  return (
    <div className={classes.wrap}>
      <div className={classes.title}>{title}</div>
      <div className={classes.contents}>
        <div className={classes.contentsWrap}>
          <div className={classes.select}>
            <Select
              value={selectedType as any}
              onChange={handleSelectChange}
              MenuProps={{
                anchorOrigin: {
                  vertical: 'bottom',
                  horizontal: 'left',
                },
                transformOrigin: {
                  vertical: -10,
                  horizontal: 0,
                },
              }}
            >
              {TYPE_MENU_ITEMS.map((item: selectedType, idx: number) => {
                return (
                  <MenuItem key={`node-management-select-${idx}`} value={item}>
                    {item}
                  </MenuItem>
                );
              })}
            </Select>
          </div>
          <div className={classes.header}>
            <NodeManagementHeader
              initializeData={initializeData}
              selectedAction={selectedAction}
              setSelectedAction={setSelectedAction}
              sortDataByType={sortDataByType}
              setNodeData={setNodeData}
              orderNode={orderNode}
              setAlert={setAlert}
            />
          </div>
          <div className={classes.table}>
            <NodeManagementTable
              nodeData={nodeData}
              pagination={pagination}
              setPagination={setPagination}
            />
          </div>
          <div className={classes.buttons}>
            <NodeManagementButtons
              disabledButtons={disabledButtons}
              setSelectedAction={setSelectedAction}
              setAlert={setAlert}
            />
          </div>
        </div>
      </div>
    </div>
  );
});

export default NodeManagement;
