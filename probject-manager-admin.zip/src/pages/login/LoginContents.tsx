import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router';
import useStore from '@/utils/useStore';
import makeStyles from '@mui/styles/makeStyles';
import { AuthApi } from '@/apis';
import PersonIcon from '@mui/icons-material/Person';
import LockIcon from '@mui/icons-material/Lock';
import frameworkIllust from '@/images/login/framework_illust.gif';

const useStyles = makeStyles(() => ({
  contents: {
    position: 'relative',
    marginLeft: 210,
    marginBottom: 'calc(100vh - 900px)',
  },
  contentsGif: {
    marginBottom: 35,
    width: 345,
    height: 230,
  },
  loginBox: {
    display: 'flex',
    alignItems: 'center',
    borderBottom: '1px solid #dbdbdb',
    padding: '10px 0',
    margin: '10px 0',
    '& :focus': {
      boxShadow: '0 0 3px 3px aliceblue',
    },
  },
  loginInput: {
    border: 'none',
    borderRadius: 2,
    margin: '0 15px',
    flexGrow: 1,
    outline: 'none',
  },
  loginError: {
    marginTop: -5,
    height: 20,
    color: 'rgb(255, 0, 0)',
  },
  loginButton: {
    border: 'none',
    borderRadius: 3,
    marginTop: 10,
    width: '100%',
    height: 55,
    fontSize: 18,
    fontWeight: 700,
    color: '#fff',
    backgroundColor: '#5E82E0',
    cursor: 'pointer',
  },
  focusedIcon: {
    color: '#01579b',
  },
}));

const LoginContents = () => {
  const [focusedIcon, setFocusedIcon] = useState<'neither' | 'id' | 'password'>(
    'neither'
  );
  const [errorMessage, setErrorMessage] = useState<string>('');
  const idInput = useRef<HTMLInputElement>(null);
  const passwordInput = useRef<HTMLInputElement>(null);
  const { AuthStore } = useStore();
  const navigate = useNavigate();
  const classes = useStyles();

  const handleIdFocus = () => {
    setFocusedIcon('id');
  };

  const handlePasswordFocus = () => {
    setFocusedIcon('password');
  };

  const handleSubmitByEnter = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'Enter') {
      handleSubmitClick();
    }
  };

  const handleSubmitClick = async () => {
    if (!idInput.current || !passwordInput.current) return;
    const userId = idInput.current.value;
    const userPassword = passwordInput.current.value;

    if (userId === '') {
      setErrorMessage('Please enter your ID');
    } else if (userPassword === '') {
      setErrorMessage('Please enter your password');
    } else {
      const response = await AuthApi.login({
        userId: userId,
        userPasswd: userPassword,
      });
      if (response.userInfoDTO) {
        AuthStore.setUser(response.userInfoDTO);
        window.sessionStorage.setItem(
          'session',
          response.userInfoDTO.userPasswd
        );
        navigate('/development/user/management');
      } else {
        setErrorMessage('The ID or password is incorrect');
      }
    }
  };

  return (
    <div className={classes.contents}>
      <img
        className={classes.contentsGif}
        src={frameworkIllust}
        alt="login-gif-logo"
      ></img>
      <div className={classes.loginBox}>
        <PersonIcon
          className={focusedIcon === 'id' ? classes.focusedIcon : ''}
        />
        <input
          className={classes.loginInput}
          placeholder="ID"
          ref={idInput}
          onFocus={handleIdFocus}
          onKeyDown={handleSubmitByEnter}
        />
      </div>
      <div className={classes.loginBox}>
        <LockIcon
          className={focusedIcon === 'password' ? classes.focusedIcon : ''}
        />
        <input
          className={classes.loginInput}
          type="password"
          placeholder="Password"
          ref={passwordInput}
          onFocus={handlePasswordFocus}
          onKeyDown={handleSubmitByEnter}
        />
      </div>
      <div className={classes.loginError}>{errorMessage}</div>
      <input
        className={classes.loginButton}
        type="submit"
        value="Login"
        onClick={handleSubmitClick}
      />
    </div>
  );
};

export default LoginContents;
