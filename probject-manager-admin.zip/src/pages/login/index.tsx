import { Navigate } from 'react-router-dom';
import makeStyles from '@mui/styles/makeStyles';
import loginBackground from '@/images/login/proobject_login_background.png';
import LoginTitle from '@/pages/login/LoginTitle';
import LoginContents from '@/pages/login/LoginContents';

const useStyles = makeStyles(() => ({
  wrap: {
    height: '100%',
  },
  background: {
    position: 'fixed',
    top: 0,
    left: 'calc(50vw - 25%)',
    transform: 'translate(-35%, -24.5%)',
    overflow: 'hidden',
    zIndex: 0,
  },
  contentWrap: {
    position: 'fixed',
    top: 0,
    left: 'calc(50vw - 25%)',
    transform: 'translateX(-25.5%)',
  },
  contentBox: {
    display: 'flex',
    alignItems: 'center',
    marginLeft: 345,
    height: '100vh',
    backgroundColor: 'transparent',
    zIndex: 1,
  },
}));

const Login = () => {
  const classes = useStyles();
  // const isLoggedIn = window.sessionStorage.getItem('session');
  const isLoggedIn = true;

  return (
    <>
      {isLoggedIn ? (
        <Navigate to="/development/node/management" />
      ) : (
        <div className={classes.wrap}>
          <img
            className={classes.background}
            src={loginBackground}
            alt="login-background"
          ></img>
          <div className={classes.contentWrap}>
            <div className={classes.contentBox}>
              <LoginTitle />
              <LoginContents />
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default Login;
