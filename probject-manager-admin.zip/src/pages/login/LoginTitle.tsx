import makeStyles from '@mui/styles/makeStyles';
import poCi from '@/images/login/proobject_ci.png';

const useStyles = makeStyles(() => ({
  title: {
    marginBottom: 'calc(100vh - 930px)',
  },
  titleImage: {
    width: 300,
    height: 106,
    marginBottom: 45,
  },
  titleDescription: {
    fontSize: 12,
    minWidth: 350,
    lineHeight: '17px',
    color: '#fff',
  },
}));

const LoginTitle = () => {
  const classes = useStyles();

  return (
    <div className={classes.title}>
      <img className={classes.titleImage} src={poCi} alt="title-logo"></img>
      <div className={classes.titleDescription}>
        Creating a web site or an application,<br></br>
        people usually have different and sometimes numerous goals.<br></br>
        Some of them in case of conversion give...
      </div>
    </div>
  );
};

export default LoginTitle;
