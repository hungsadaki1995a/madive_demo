import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Divider,
  FormControlLabel,
  FormGroup,
  styled,
} from '@mui/material';
import Checkbox from '@mui/material/Checkbox';
import { useEffect, useState } from 'react';
import { MetaApi } from '@/apis';
import { metaType } from '@/types/typeBundle';
import { useStore } from '@/utils';
import { initialMetaValue } from './MetaManagement';
import {
  DialogSelectRow,
  DialogTextRow,
} from './MetaManagementHeaderDialogRow';

interface PropsType {
  openDialog: boolean;
  handleOpenDialogChange: (newState: boolean) => void;
  selectedAction: { action: string; metaId: string };
  initializeData: () => void;
  setAlert: (severity: 'success' | 'error', errorMessage: string) => void;
}

const MetaManagementHeaderDialog = (props: PropsType) => {
  const {
    openDialog,
    handleOpenDialogChange,
    selectedAction,
    initializeData,
    setAlert,
  } = props;
  const [metaValue, setMetaValue] = useState<metaType>(initialMetaValue);
  const [keepOpen, setKeepOpen] = useState<boolean>(false);
  const { MetaStore } = useStore();
  const decimalActive = ['float', 'double', 'Double', 'BigDecimal'];

  const handleCloseDialog = () => {
    MetaStore.setSelectedMeta([]);
    handleOpenDialogChange(false);
    setKeepOpen(false);
    setMetaValue(initialMetaValue);
  };

  const handleCloseButton = () => {
    handleOpenDialogChange(false);
    setKeepOpen(false);
    handleCloseDialog();
  };

  const handleCheckboxChange = () => {
    setKeepOpen(!keepOpen);
  };

  const handleRequestSuccess = () => {
    if (!keepOpen) {
      handleCloseDialog();
      MetaStore.setSelectedMeta([]);
    }
    initializeData();
    setAlert('success', 'The request was successfully done.');
  };

  const checkSubmitValue = () => {
    const TITLES: { [key: string]: string } = {
      physicalName: 'Physical Name',
      logicalName: 'Logical Name',
      fieldType: 'Field Type',
      length: 'Length',
      metaType: 'Meta Type',
    };
    const emptyStrings: string[] = Object.entries(TITLES)
      .filter(
        (title) =>
          (metaValue as unknown as { [key: string]: string })[title[0]] ===
            '' &&
          (title[0] !== 'length' || metaValue.fieldType !== 'Date')
      )
      .map((title) => title[1]);
    if (emptyStrings.length > 0) {
      setAlert(
        'error',
        `Please enter values for the following: ${emptyStrings.join(', ')}.`
      );
      return false;
    }
    return true;
  };

  const checkDateFormat = (dateFormat: string) => {
    const dateFormatMatch = !dateFormat.match(/^\d{4}\.\d{2}\.\d{2}$/);
    return !dateFormatMatch && new Date(dateFormat).getTime();
  };

  const checkTimeFormat = (timeFormat: string) => {
    const timeFormatMatch = !timeFormat.match(/^\d{2}\.\d{2}\.\d{2}$/);
    if (timeFormatMatch) return false;

    const [hour, min, sec]: string[] = timeFormat.split('.');
    if (Number(hour) < 0 || Number(hour) >= 24) return false;
    if (Number(min) < 0 || Number(min) >= 60) return false;
    if (Number(sec) < 0 || Number(sec) >= 60) return false;
    return true;
  };

  const checkDateDefaultValue = () => {
    if (metaValue.fieldType !== 'Date' || !metaValue.defaultValue) {
      return true;
    }
    const format: string[] = metaValue.defaultValue.split(' ');
    if (format.length === 1 && format[0] === '') {
      return true;
    }
    if (format.length !== 2) {
      setAlert(
        'error',
        'Please check the format of the Default Value. (Field Type: Date)'
      );
      return false;
    }
    const [dateFormat, timeFormat]: string[] = format;
    if (!checkDateFormat(dateFormat)) {
      setAlert(
        'error',
        'Please check the date format of the Default Value. (Field Type: Date)'
      );
      return false;
    }
    if (!checkTimeFormat(timeFormat)) {
      setAlert(
        'error',
        'Please check the time format of the Default Value. (Field Type: Date)'
      );
      return false;
    }
    return true;
  };

  const handleSubmitDialog = async () => {
    if (selectedAction.action === 'Delete') {
      const submitValue = MetaStore.selectedMeta.map((metaId: string) => ({
        metaId,
      }));
      const response = await MetaApi.delete(submitValue);
      const errorMessage = (response as { data: { errorMsg: string } }).data
        ?.errorMsg;
      if ((response as { data: { success: boolean } }).data?.success) {
        handleRequestSuccess();
      } else if (errorMessage !== null && errorMessage !== undefined) {
        setAlert('error', `The request failed: ${errorMessage}`);
      }
      return;
    }
    if (checkSubmitValue() && checkDateDefaultValue()) {
      if (metaValue.length !== String(Number(metaValue.length))) {
        setAlert('error', 'Please enter a number for Length.');
        return;
      }
      if (
        metaValue.decimalSize !== String(Number(metaValue.decimalSize)) &&
        decimalActive.includes(metaValue.fieldType)
      ) {
        setAlert('error', 'Please enter a number for Decimal.');
        return;
      }
      const response =
        selectedAction.action === 'Action'
          ? await MetaApi.add(metaValue)
          : await MetaApi.edit(metaValue);
      const errorMessage = (response as { data: { errorMsg: string } }).data
        ?.errorMsg;
      if (errorMessage === null || errorMessage === undefined) {
        handleRequestSuccess();
      } else {
        setAlert('error', `Request failed: ${errorMessage}`);
      }
    }
  };

  const handleSelectedAction = async () => {
    const targetMeta = MetaStore.meta.find(
      (user: metaType) => selectedAction.metaId === user.metaId
    );
    if (targetMeta && targetMeta.length === 0) {
      setAlert('error', 'There is no such meta data.');
      return;
    }
    setMetaValue(targetMeta || initialMetaValue);
    handleOpenDialogChange(true);
  };

  const handleMetaValueChange = (newMetaValue: metaType) => {
    setMetaValue(newMetaValue);
  };

  useEffect(() => {
    if (selectedAction.action === 'Action') return;
    handleSelectedAction();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedAction]);

  return (
    <CustomDialog
      maxWidth="md"
      open={openDialog}
      onClose={handleCloseDialog}
      aria-labelledby="form-dialog-title"
    >
      {selectedAction.action === 'Delete' ? (
        <>
          <CustomDialogTitle id="form-dialog-title">
            Delete Meta
          </CustomDialogTitle>
          <CustomDivider />
          <DialogDelete>
            Are you sure to delete all checked meta data?
          </DialogDelete>
          <DialogActions>
            <Button
              onClick={handleSubmitDialog}
              color="primary"
              variant="contained"
            >
              OK
            </Button>
            <Button
              color="inherit"
              onClick={handleCloseButton}
              variant="contained"
            >
              Cancel
            </Button>
          </DialogActions>
        </>
      ) : (
        <>
          <CustomDialogTitle id="form-dialog-title">
            {`${
              selectedAction.action === 'Action' ? 'Create' : 'Edit'
            } Meta Field`}
          </CustomDialogTitle>
          <CustomDivider />
          <CustomDialogContent>
            <DialogTextRow
              metaValue={metaValue}
              handleMetaValueChange={handleMetaValueChange}
              title="Physical Name*"
              name="physicalName"
              value={metaValue.physicalName}
            />
            <DialogTextRow
              metaValue={metaValue}
              handleMetaValueChange={handleMetaValueChange}
              title="Logical Name*"
              name="logicalName"
              value={metaValue.logicalName}
            />
            <DialogSelectRow
              metaValue={metaValue}
              handleMetaValueChange={handleMetaValueChange}
              title="Field Type*"
              name="fieldType"
              value={metaValue.fieldType}
            />
            <LengthDecimal>
              <DialogTextRow
                metaValue={metaValue}
                handleMetaValueChange={handleMetaValueChange}
                title="Length*"
                name="length"
                value={metaValue.length}
              />
              <DialogTextRow
                metaValue={metaValue}
                handleMetaValueChange={handleMetaValueChange}
                title="Decimal"
                name="decimalSize"
                value={metaValue.decimalSize}
              />
            </LengthDecimal>
            <DialogTextRow
              metaValue={metaValue}
              handleMetaValueChange={handleMetaValueChange}
              title="Comments"
              name="comments"
              value={metaValue.comments}
            />
            <DialogTextRow
              metaValue={metaValue}
              handleMetaValueChange={handleMetaValueChange}
              title="Default Value"
              name="defaultValue"
              value={metaValue.defaultValue}
            />
          </CustomDialogContent>
          <DialogActions>
            <CustomCheckBox>
              <FormControlLabel
                control={
                  <Checkbox size="small" onChange={handleCheckboxChange} />
                }
                label="Keep Open"
              />
            </CustomCheckBox>
            <Button
              onClick={handleSubmitDialog}
              color="primary"
              variant="contained"
            >
              OK
            </Button>
            <Button
              color="inherit"
              onClick={handleCloseButton}
              variant="contained"
            >
              Cancel
            </Button>
          </DialogActions>
        </>
      )}
    </CustomDialog>
  );
};

export default MetaManagementHeaderDialog;

export const CustomDialog = styled(Dialog)({
  '& .MuiDialog-container': {
    minWidth: 695,
  },
});

export const CustomDialogTitle = styled(DialogTitle)({
  '& h2': {
    fontSize: 16,
    fontWeight: 600,
    color: '#444',
  },
});

export const CustomDivider = styled(Divider)({
  margin: '0px 20px',
});

export const DialogDelete = styled(DialogContent)({
  padding: 50,
});

export const CustomDialogContent = styled(DialogContent)({
  overflowX: 'hidden',
  '& p': {
    display: 'flex',
    alignItems: 'center',
    width: 175,
    fontSize: 14,
    margin: 0,
  },
  '& input': {
    padding: '5px 10px',
    width: 312,
    fontSize: 14,
    color: '#555',
  },
  '& input[type=radio]': {
    width: 'fit-content',
  },
  '& .Mui-disabled[type=text]': {
    backgroundColor: 'rgba(0, 0, 0, 0.1)',
  },
  '& .Mui-disabled[role=button]': {
    backgroundColor: 'rgba(0, 0, 0, 0.1)',
  },
});

export const LengthDecimal = styled('div')({
  display: 'flex',
  alignItems: 'center',
  margin: '-10px 0',
  '& input': {
    width: 90,
  },
});

export const DialogBoxRange = styled('div')({
  display: 'flex',
  margin: '-10px 0 -12px 175px',
  '& input': {
    marginLeft: -100,
    width: 80,
  },
  '& fieldset': {
    left: -100,
  },
});

export const CustomCheckBox = styled(FormGroup)({
  marginRight: 312,
  '& span': {
    fontSize: 14,
  },
});
