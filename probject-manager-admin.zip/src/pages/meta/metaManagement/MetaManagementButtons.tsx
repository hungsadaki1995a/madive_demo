import { styled } from '@mui/material';
import { SelectedActionType } from './MetaManagement';
import { useStore } from '@/utils';

interface PropsType {
  disabledButtons: { change: boolean; delete: boolean };
  handleSelectedActionChange: (newSelectedAction: SelectedActionType) => void;
  setAlert: (severity: 'success' | 'error', message: string) => void;
}

const MetaManagementButtons = (props: PropsType) => {
  const { disabledButtons, handleSelectedActionChange, setAlert } = props;
  const { MetaStore } = useStore();

  const handleClickChange = () => {
    if (MetaStore.selectedMeta.length !== 1) {
      setAlert('error', 'The length of selected data should be 1.');
      return;
    }
    handleSelectedActionChange({
      action: 'Edit',
      metaId: MetaStore.selectedMeta[0],
    });
  };

  const handleClickDelete = () => {
    if (MetaStore.selectedMeta.length === 0) {
      setAlert('error', 'There is no data selected.');
      return;
    }
    handleSelectedActionChange({ action: 'Delete', metaId: '' });
  };

  return (
    <Warp>
      <Button disabled={disabledButtons.change} onClick={handleClickChange}>
        Change
      </Button>
      <Button disabled={disabledButtons.delete} onClick={handleClickDelete}>
        Delete
      </Button>
    </Warp>
  );
};

export default MetaManagementButtons;

export const Warp = styled('div')({
  display: 'flex',
});

export const Button = styled('button')({
  border: 'none',
  borderRadius: 0,
  padding: '5px 0',
  margin: '0 10px',
  width: 90,
  height: 35,
  color: '#fff',
  backgroundColor: '#4085ee',
  cursor: 'pointer',
});
