import React, { useState, useEffect, useCallback } from 'react';
import { observer } from 'mobx-react';
import {
  Table,
  TableHead,
  TableBody,
  TableCell,
  TableContainer,
  TablePagination,
  TableRow,
  TableSortLabel,
  styled,
} from '@mui/material';
import CheckBox from '@mui/material/Checkbox';
import { useStore } from '@/utils';
import { MetaApi } from '@/apis';
import {
  metaType,
  metaSelectionType,
  paginationType,
} from '@/types/typeBundle';
import { TableBodyContents, TableEmpty } from '@/components/molecules';

interface PropsType {
  metaData: metaType[];
  handleMetaChange: (newMetaData: metaType[]) => void;
  pagination: paginationType;
  handlePaginationChange: (newPagination: Partial<paginationType>) => void;
  searchValues: { physicalName: string; logicalName: string };
  orderMeta: (
    meta: metaType[],
    order: 'asc' | 'desc',
    field: keyof metaType
  ) => metaType[];
  setAlert: (severity: 'error' | 'success', message: string) => void;
}

const MetaManagementTable = observer((props: PropsType) => {
  const {
    metaData,
    handleMetaChange,
    pagination,
    handlePaginationChange,
    searchValues,
    orderMeta,
    setAlert,
  } = props;
  const [data, setData] = useState<metaSelectionType[]>([]);
  const options = { startWith: 'FALSE', contains: 'TRUE' };
  const { MetaStore } = useStore();
  const columns = [
    { title: 'Selection', field: 'selection' },
    { title: 'Physical Name', field: 'physicalName' },
    { title: 'Logical Name', field: 'logicalName' },
    { title: 'Comments', field: 'comments' },
    { title: 'Field Type', field: 'fieldType' },
    { title: 'Length', field: 'length' },
  ];

  const handleOrderTable = (field: string) => {
    const newOrder =
      field === MetaStore.orderProperty
        ? MetaStore.order === 'asc'
          ? 'desc'
          : 'asc'
        : 'asc';
    MetaStore.setOrderProperty(field);
    MetaStore.setOrder(newOrder);
    handleMetaChange(orderMeta(metaData, newOrder, field as keyof metaType));
  };

  const handleHeaderCheckboxChange = () => {
    const allDataChecked = MetaStore.selectedMeta.length === metaData.length;
    const newSelectedData = !allDataChecked
      ? metaData.map((meta) => meta.metaId)
      : [];
    MetaStore.setSelectedMeta(newSelectedData);
    handleMetaChange(
      orderMeta(
        metaData,
        MetaStore.order,
        MetaStore.orderProperty as keyof metaType
      )
    );
  };

  const handlePageChange = async (e: React.MouseEvent | null, page: number) => {
    handlePaginationChange({ page });
    const response = await MetaApi.get('/metaList', {
      ...options,
      page: page + 1,
      pageRowNum: pagination.pageSize,
      physicalName: searchValues.physicalName,
      logicalName: searchValues.logicalName,
    });
    if (response.metaInfoDTOArray) {
      MetaStore.setMeta(response.metaInfoDTOArray);
      handleMetaChange(
        orderMeta(
          [...response.metaInfoDTOArray],
          MetaStore.order,
          MetaStore.orderProperty as keyof metaType
        )
      );
    } else {
      const errorMessage = (response as { data: { errorMsg: string } }).data
        ?.errorMsg;
      if (errorMessage === null || errorMessage === undefined) {
        setAlert('error', 'Request failed with unknown error');
      } else {
        setAlert('error', `Request failed: ${errorMessage}`);
      }
    }
  };

  const handleRowsPerPageChange = async (e: React.ChangeEvent) => {
    const newPageSize = Number((e.target as HTMLInputElement).value);
    handlePaginationChange({ pageSize: newPageSize });
    const response = await MetaApi.get('/metaList', {
      ...options,
      page: 1,
      pageRowNum: newPageSize,
      physicalName: searchValues.physicalName,
      logicalName: searchValues.logicalName,
    });
    if (response.metaInfoDTOArray) {
      MetaStore.setMeta(response.metaInfoDTOArray);
      handleMetaChange(
        orderMeta(
          [...response.metaInfoDTOArray],
          MetaStore.order,
          MetaStore.orderProperty as keyof metaType
        )
      );
    } else {
      const errorMessage = (response as { data: { errorMsg: string } }).data
        ?.errorMsg;
      if (errorMessage === null || errorMessage === undefined) {
        setAlert('error', 'Request failed with unknown error');
      } else {
        setAlert('error', `Request failed: ${errorMessage}`);
      }
    }
  };

  const setNewData = useCallback(() => {
    const handleBodyCheckboxClick = (meta: metaType) => {
      if (MetaStore.selectedMeta.includes(meta.metaId)) {
        const newSelectedData = MetaStore.selectedMeta.filter(
          (metaId: string) => metaId !== meta.metaId
        );
        MetaStore.setSelectedMeta(newSelectedData);
      } else {
        const newSelectedData = [...MetaStore.selectedMeta, meta.metaId];
        MetaStore.setSelectedMeta(newSelectedData);
      }
      handleMetaChange(
        orderMeta(
          metaData,
          MetaStore.order,
          MetaStore.orderProperty as keyof metaType
        )
      );
    };
    setData(
      metaData.map((meta) => ({
        ...meta,
        selection: (
          <CheckBox
            color="info"
            checked={MetaStore.selectedMeta.includes(meta.metaId)}
            onClick={() => handleBodyCheckboxClick(meta)}
          />
        ),
      }))
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [MetaStore, metaData, orderMeta]);

  useEffect(() => {
    setNewData();
  }, [
    setNewData,
    MetaStore.order,
    MetaStore.orderProperty,
    MetaStore.selectedMeta,
  ]);

  return (
    <TableContainer>
      <Table>
        <TableHead>
          <TableRow>
            <CheckboxContainer>
              <CheckBox
                color="info"
                checked={
                  MetaStore.selectedMeta.length !== 0 &&
                  MetaStore.selectedMeta.length === metaData.length
                }
                onChange={handleHeaderCheckboxChange}
              />
            </CheckboxContainer>
            {columns.map((column) => {
              const isSelection = column.field === 'selection';
              return isSelection ? (
                <EmptyHeader key={`meta-head-${column.field}`} />
              ) : (
                <TableCell key={`meta-head-${column.field}`}>
                  <TableSortLabel
                    active={MetaStore.orderProperty === column.field}
                    direction={
                      MetaStore.orderProperty === column.field
                        ? MetaStore.order
                        : 'asc'
                    }
                    onClick={() => handleOrderTable(column.field)}
                  >
                    {column.title}
                  </TableSortLabel>
                </TableCell>
              );
            })}
          </TableRow>
        </TableHead>
        <TableBody>
          {data.length === 0 ? (
            <TableEmpty />
          ) : (
            <TableBodyContents data={data} columns={columns} />
          )}
          <TableRow>
            <CustomTablePagination
              rowsPerPageOptions={[10, 25, 50]}
              count={pagination.totalCount}
              rowsPerPage={pagination.pageSize}
              page={pagination.page}
              onPageChange={handlePageChange}
              onRowsPerPageChange={handleRowsPerPageChange}
            />
          </TableRow>
        </TableBody>
      </Table>
    </TableContainer>
  );
});

export default MetaManagementTable;

export const CustomTablePagination = styled(TablePagination)({
  position: 'fixed',
  bottom: 20,
  borderBottom: 'none',
  minWidth: 1330,
  width: 'calc(100vw - 310px)',
  '& div p, div div': {
    fontSize: '0.875rem',
    color: '#000',
  },
});

export const CheckboxContainer = styled(TableCell)({
  width: 24,
});

export const EmptyHeader = styled('td')({
  display: 'none',
});
