import React from 'react';
import {
  TextField,
  Select,
  SelectChangeEvent,
  MenuItem,
  DialogContentText,
  Radio,
  RadioGroup,
  FormControlLabel,
  styled,
} from '@mui/material';
import { metaType } from '@/types/typeBundle';

interface PropsType {
  metaValue: metaType;
  handleMetaValueChange: (newMetaValue: metaType) => void;
  title: string;
  name: string;
  value: string | boolean;
}

export const DialogTextRow = (props: PropsType) => {
  const { metaValue, handleMetaValueChange, title, name, value } = props;
  const decimalActive = ['float', 'double', 'Double', 'BigDecimal'];
  const DATE_PLACEHOLDER =
    title === 'Default Value' && metaValue.fieldType === 'Date'
      ? 'Format: YYYY.MM.DD HH.MM.SS'
      : '';
  const lengthDisabled = title === 'Length' && metaValue.fieldType === 'Date';
  const rangeDisabled =
    title === 'Range' &&
    (metaValue.fieldType !== 'String' || !metaValue.masking);
  const decimalDisabled =
    title === 'Decimal' && !decimalActive.includes(metaValue.fieldType);
  const dynamicRequiredField =
    title === 'Decimal' && decimalActive.includes(metaValue.fieldType);

  const handleTextChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    handleMetaValueChange({ ...metaValue, [e.target.name]: e.target.value });
  };

  return title === 'Decimal' ? (
    <DialogBoxDecimal>
      <DialogTitle>{dynamicRequiredField ? title + '*' : title}</DialogTitle>
      <TextField
        name={name}
        placeholder={DATE_PLACEHOLDER}
        value={value ?? ''}
        disabled={lengthDisabled || rangeDisabled || decimalDisabled}
        autoComplete="off"
        onChange={handleTextChange}
        spellCheck="false"
      />
    </DialogBoxDecimal>
  ) : (
    <DialogBox>
      <DialogTitle>{dynamicRequiredField ? title + '*' : title}</DialogTitle>
      <TextField
        name={name}
        placeholder={DATE_PLACEHOLDER}
        value={value ?? ''}
        disabled={lengthDisabled || rangeDisabled || decimalDisabled}
        autoComplete="off"
        onChange={handleTextChange}
        spellCheck="false"
      />
    </DialogBox>
  );
};

export const DialogSelectRow = (props: PropsType) => {
  const { metaValue, handleMetaValueChange, title, name, value } = props;
  const decimalActive = ['float', 'double', 'Double', 'BigDecimal'];
  const disabled =
    title !== 'Field Type*' && metaValue.metaType === 'non-persistent';
  const selectItems: { [key: string]: string[] } = {
    nodeType: ['TEST', 'RUNTIME', 'MASTER'],
    fieldType: [
      'String',
      'short',
      'int',
      'long',
      'float',
      'double',
      'Short',
      'Integer',
      'Long',
      'Double',
      'BigInteger',
      'BigDecimal',
      'char',
      'boolean',
      'Date',
    ],
  };

  const handleSelectChange = (
    e: SelectChangeEvent<{ value: string } | unknown>
  ) => {
    const fieldType =
      e.target.name === 'fieldType'
        ? (e.target.value as string)
        : metaValue.fieldType;
    handleMetaValueChange({
      ...metaValue,
      [e.target.name]: e.target.value,
      decimalSize: decimalActive.includes(fieldType)
        ? metaValue.decimalSize
        : '',
    });
  };

  return (
    <DialogBox>
      <DialogTitle>{title}</DialogTitle>
      <DialogSelect
        id={name}
        name={name}
        disabled={disabled}
        value={(value as any) || ''}
        onChange={handleSelectChange}
        MenuProps={{
          anchorOrigin: {
            vertical: 'bottom',
            horizontal: 'left',
          },
          transformOrigin: {
            vertical: -3,
            horizontal: 0,
          },
        }}
      >
        {selectItems[name] ? (
          selectItems[name].map((item) => (
            <MenuItem value={item} key={`meta-menu-item-${item}`}>
              {item}
            </MenuItem>
          ))
        ) : (
          <MenuItem value="">No Option Available</MenuItem>
        )}
      </DialogSelect>
    </DialogBox>
  );
};

export const DialogBooleanRow = (props: PropsType) => {
  const { metaValue, handleMetaValueChange, title, name } = props;
  const primaryKeyDiabled =
    title === 'Primary Key' && metaValue.metaType === 'non-persistent';
  const maskingEncryptDisabled =
    (title === 'Masking' || title === 'Encrypt') &&
    metaValue.fieldType !== 'String';
  const radioItems: { [key: string]: string[] } = {
    metaType: ['non-persistent', 'persistent'],
    isKey: ['yes', 'no'],
    masking: ['Use', 'Unuse'],
    encrypt: ['Use', 'Unuse'],
    isUse: ['yes', 'no'],
  };

  const handleRadioChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const radioValue = radioItems[e.target.name].indexOf(e.target.value) === 0;
    handleMetaValueChange({
      ...metaValue,
      [e.target.name]: radioItems[e.target.name][radioValue ? 0 : 1],
    });
  };

  return (
    <DialogBox>
      <DialogTitle>{title}</DialogTitle>
      <CustomRadioGroup
        row
        defaultValue={
          radioItems[name][title === 'Type' || title === 'Encrypt' ? 0 : 1]
        }
      >
        {radioItems[name].map((item) => (
          <FormControlLabel
            disabled={primaryKeyDiabled || maskingEncryptDisabled}
            key={`meta-radio-item-${item}`}
            value={item}
            control={<Radio name={name} onChange={handleRadioChange} />}
            label={item}
          />
        ))}
      </CustomRadioGroup>
    </DialogBox>
  );
};

export const DialogTitle = styled(DialogContentText)({
  '& h2': {
    fontSize: 16,
    fontWeight: 600,
    color: '#444',
  },
});

export const DialogBox = styled('div')({
  display: 'flex',
  margin: '12px 35px',
});

export const DialogBoxDecimal = styled('div')({
  display: 'flex',
  '& input': {
    width: 80,
    marginLeft: -100,
  },
  '& fieldset': {
    left: -100,
  },
});

export const DialogSelect = styled(Select)({
  width: 150,
  fontSize: 14,
  '& div': {
    padding: '5px 10px',
  },
});

export const CustomRadioGroup = styled(RadioGroup)({
  width: 312,
  '& span': {
    fontSize: 14,
  },
});
