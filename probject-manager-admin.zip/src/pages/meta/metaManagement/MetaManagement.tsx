import { useState, useEffect } from 'react';
import { observer } from 'mobx-react';
import { styled } from '@mui/material';
import useStore from '@/utils/useStore';
import { MetaApi } from '@/apis';
import MetaManagementHeader from './MetaManagementHeader';
import MetaManagementTable from './MetaManagementTable';
import MetaManagementButtons from './MetaManagementButtons';
import { metaType, paginationType } from '@/types/typeBundle';

export const initialMetaValue = {
  columnName: '',
  comments: '',
  creator: '',
  dbType: '',
  decimalSize: '',
  defaultValue: '',
  encrypt: 'unuse',
  fieldType: '',
  isKey: 'n',
  isUse: 'y',
  length: '',
  logicalName: '',
  masking: 'unuse',
  maskingRange: '',
  metaId: '',
  metaType: 'non-persistent',
  physicalName: '',
  resourceGroup: '',
  tableName: '',
};

export type SelectedActionType = { action: string; metaId: string };
export type SearchValuesType = { physicalName: string; logicalName: string };
interface PropsType {
  title: string;
}

const MetaManagement = observer((props: PropsType) => {
  const { title } = props;
  const [metaData, setMetaData] = useState<metaType[]>([]);
  const [searchValues, setSearchValues] = useState<SearchValuesType>({
    physicalName: '',
    logicalName: '',
  });
  const [disabledButtons, setDisabledButtons] = useState<{
    change: boolean;
    delete: boolean;
  }>({ change: true, delete: true });
  const [selectedAction, setSelectedAction] = useState<SelectedActionType>({
    action: 'Action',
    metaId: '',
  });
  const [pagination, setPagination] = useState<paginationType>({
    page: 0,
    pageSize: 10,
    totalCount: 0,
  });

  const { MetaStore, AlertStore } = useStore();
  const STATUS = { isFetching: false };

  const compareValues = (prev: string | number, next: string | number) => {
    if (prev > next) return 1;
    if (prev < next) return -1;
    return 0;
  };

  const orderMeta = (
    meta: metaType[],
    order: 'asc' | 'desc',
    field: keyof metaType
  ) => {
    let thisOrder = 0;
    const newOrder = order === 'asc' ? 1 : -1;
    return meta.sort((a, b) => {
      if (a[field] === null) return order === 'asc' ? -1 : 1;
      if (b[field] === null) return order === 'asc' ? 1 : -1;
      if (
        String(Number(a[field])) === a[field] &&
        String(Number(b[field])) === b[field]
      ) {
        thisOrder = compareValues(Number(a[field]), Number(b[field]));
      } else {
        thisOrder = compareValues(String(a[field]), String(b[field]));
      }
      return newOrder * thisOrder;
    });
  };

  const initializeData = async () => {
    STATUS.isFetching = true;
    const data = await MetaApi.get('/metaList', {
      page: pagination.page + 1,
      pageRowNum: 10,
      physicalName: searchValues.physicalName,
      logicalName: searchValues.logicalName,
    });
    if (data.success) {
      MetaStore.setMeta(data.metaInfoDTOArray || []);
      setMetaData(
        orderMeta(
          [...(data.metaInfoDTOArray || [])],
          MetaStore.order,
          MetaStore.orderProperty
        )
      );
      setPagination({ ...pagination, totalCount: data.totalCount });
    }
    STATUS.isFetching = false;
  };

  const setAlert = async (severity: 'error' | 'success', message: string) => {
    AlertStore.openApiAlert(severity, message);
  };

  const handleMetaChange = (newMetaData: metaType[]) => {
    setMetaData(newMetaData);
  };

  const handleSelectedActionChange = (
    newSelectedAction: SelectedActionType
  ) => {
    setSelectedAction(newSelectedAction);
  };

  const handlePaginationChange = (newPagination: Partial<paginationType>) => {
    setPagination({ ...pagination, ...newPagination });
  };

  const handleSearchValuesChange = (newSearchValues: SearchValuesType) => {
    setSearchValues(newSearchValues);
  };

  useEffect(() => {
    if (STATUS.isFetching) return;
    MetaStore.setOrder('asc');
    MetaStore.setOrderProperty('physicalName');
    initializeData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (MetaStore.selectedMeta.length === 0) {
      setDisabledButtons({ change: true, delete: true });
    } else if (MetaStore.selectedMeta.length === 1) {
      setDisabledButtons({ change: false, delete: false });
    } else {
      setDisabledButtons({ change: true, delete: false });
    }
  }, [MetaStore.selectedMeta]);

  return (
    <Wrap>
      <Title>{title}</Title>
      <Contents>
        <ContentsWrap>
          <Header>
            <MetaManagementHeader
              handleMetaChange={handleMetaChange}
              selectedAction={selectedAction}
              handleSelectedActionChange={handleSelectedActionChange}
              pagination={pagination}
              handlePaginationChange={handlePaginationChange}
              initializeData={initializeData}
              handleSearchValuesChange={handleSearchValuesChange}
              orderMeta={orderMeta}
              setAlert={setAlert}
            />
          </Header>
          <CustomTable>
            <MetaManagementTable
              metaData={metaData}
              handleMetaChange={handleMetaChange}
              pagination={pagination}
              handlePaginationChange={handlePaginationChange}
              searchValues={searchValues}
              orderMeta={orderMeta}
              setAlert={setAlert}
            />
          </CustomTable>
          <Buttons>
            <MetaManagementButtons
              disabledButtons={disabledButtons}
              handleSelectedActionChange={handleSelectedActionChange}
              setAlert={setAlert}
            />
          </Buttons>
        </ContentsWrap>
      </Contents>
    </Wrap>
  );
});

export default MetaManagement;

const Wrap = styled('div')({
  width: 'calc(100vw - 240px)',
  height: 'calc(100vh - 50px)',
});

const Title = styled('div')({
  padding: 13,
  minWidth: 200,
  color: 'rgb(39, 111, 195)',
});

const Contents = styled('div')({
  padding: 20,
  width: 'calc(100vw - 280px)',
  minWidth: 1360,
  height: 'calc(100vh - 135px)',
  minHeight: 750,
  backgroundColor: '#E8EDF1',
});

const ContentsWrap = styled('div')({
  width: '100%',
  height: '100%',
  backgroundColor: '#fff',
});

const Header = styled('div')({
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  padding: '10px 10px 5px',
});

const CustomTable = styled('div')({
  padding: 12,
  maxHeight: 660,
  overflowY: 'auto',
  '& table': {
    tableLayout: 'fixed',
  },
  '& div': {
    boxShadow: 'none',
  },
  '& thead tr': {
    position: 'sticky',
    top: 0,
    zIndex: 1,
  },
  '& thead tr th': {
    fontSize: 12,
    fontWeight: 600,
    backgroundColor: '#f4f7fc',
    whiteSpace: 'nowrap',
    padding: 12,
    '& span': {
      padding: 0,
    },
  },
  '& tbody': {
    padding: '0 16px',
    backgroundColor: '#fff',
    '& tr:hover': {
      backgroundColor: '#e6f4ff',
      '& td': {
        fontWeight: 600,
        color: '#000',
      },
    },
    '& td': {
      padding: 12,
      fontSize: 12,
      whiteSpace: 'nowrap',
      fontWeight: 450,
      color: '#888',
      '& span': {
        padding: 0,
      },
    },
  },
});

export const Buttons = styled('div')({
  position: 'fixed',
  bottom: 30,
  padding: '10px 10px 5px',
  '& :disabled': {
    backgroundColor: '#000',
    cursor: 'not-allowed',
  },
});
