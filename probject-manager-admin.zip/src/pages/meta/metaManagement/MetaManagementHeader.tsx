import React, { useState, useRef } from 'react';
import { observer } from 'mobx-react';
import AddIcon from '@mui/icons-material/Add';
import { styled } from '@mui/material';
import { SelectedActionType, SearchValuesType } from './MetaManagement';
import { useStore } from '@/utils';
import { MetaApi } from '@/apis';
import { metaType, paginationType } from '@/types/typeBundle';
import MetaManagementHeaderDialog from './MetaManagementHeaderDialog';

interface PropsType {
  handleMetaChange: (newMetaData: metaType[]) => void;
  selectedAction: { action: string; metaId: string };
  handleSelectedActionChange: (newSelectedAction: SelectedActionType) => void;
  pagination: paginationType;
  handlePaginationChange: (newPagination: Partial<paginationType>) => void;
  initializeData: () => void;
  handleSearchValuesChange: (newSearchValues: SearchValuesType) => void;
  orderMeta: (
    meta: metaType[],
    order: 'asc' | 'desc',
    field: keyof metaType
  ) => metaType[];
  setAlert: (severity: 'success' | 'error', errorMessage: string) => void;
}

const MetaManagementHeader = observer((props: PropsType) => {
  const {
    handleMetaChange,
    selectedAction,
    handleSelectedActionChange,
    pagination,
    handlePaginationChange,
    initializeData,
    handleSearchValuesChange,
    orderMeta,
    setAlert,
  } = props;
  const [openDialog, setOpenDialog] = useState<boolean>(false);
  const physicalRef = useRef<HTMLInputElement>(null);
  const logicalRef = useRef<HTMLInputElement>(null);
  const { MetaStore } = useStore();
  const TITLE = 'Create New Meta';

  const handleCreateClick = () => {
    handleSelectedActionChange({ action: 'Action', metaId: '' });
    setOpenDialog(true);
  };

  const handleSearchClick = async () => {
    if (!physicalRef.current || !logicalRef.current) return;
    const physicalName = physicalRef.current.value;
    const logicalName = logicalRef.current.value;
    const options = { startWith: 'FALSE', contains: 'TRUE' };
    const response = await MetaApi.get('/metaList', {
      ...options,
      page: 1,
      pageRowNum: pagination.pageSize,
      physicalName,
      logicalName,
    });
    handlePaginationChange({
      page: 0,
      totalCount: response.totalCount,
    });
    MetaStore.setSelectedMeta([]);
    if (response.success) {
      MetaStore.setMeta(response.metaInfoDTOArray || []);
      handleMetaChange(
        orderMeta(
          [...(response.metaInfoDTOArray || [])],
          MetaStore.order,
          MetaStore.orderProperty
        )
      );
    } else {
      const errorMessage = (response as { data: { errorMsg: string } }).data
        ?.errorMsg;
      if (errorMessage === null || errorMessage === undefined) {
        setAlert('error', 'Request failed with unknown error');
      } else {
        setAlert('error', `Request failed: ${errorMessage}`);
      }
    }
  };

  const handleSubmitByEnter = (e: React.KeyboardEvent) => {
    handleSearchValuesChange({
      physicalName: physicalRef.current?.value || '',
      logicalName: logicalRef.current?.value || '',
    });
    if (e.key === 'Enter') {
      handleSearchClick();
    }
  };

  const handleOpenDialogChange = (newState: boolean) => {
    setOpenDialog(newState);
  };

  return (
    <>
      <Wrap>
        <Create onClick={handleCreateClick}>
          <AddIcon />
          {TITLE}
        </Create>
        <div>
          <Title>Physical Name</Title>
          <Input
            type="text"
            ref={physicalRef}
            onKeyDown={handleSubmitByEnter}
          />
          <Title>Logical Name</Title>
          <Input type="text" ref={logicalRef} onKeyDown={handleSubmitByEnter} />
          <Button onClick={handleSearchClick}>Search</Button>
        </div>
      </Wrap>
      <MetaManagementHeaderDialog
        openDialog={openDialog}
        handleOpenDialogChange={handleOpenDialogChange}
        selectedAction={selectedAction}
        initializeData={initializeData}
        setAlert={setAlert}
      />
    </>
  );
});

export default MetaManagementHeader;

export const Wrap = styled('div')({
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  flexGrow: 1,
  padding: 0,
  fontSize: 13,
});

export const Create = styled('div')({
  display: 'flex',
  alignItems: 'center',
  border: '1px solid #0175bc',
  padding: 5,
  color: '#0175bc',
  fontSize: 14,
  cursor: 'pointer',
  '& svg': {
    color: '#0175bc',
  },
});

export const Title = styled('span')({
  marginLeft: 5,
});

export const Input = styled('input')({
  border: '1px solid #dbdbdb',
  padding: '0 10px',
  margin: '0 10px',
  outline: 'none',
  width: 125,
  height: 25,
});

export const Button = styled('button')({
  border: 'none',
  borderRadius: 0,
  width: 75,
  height: 25,
  color: '#fff',
  backgroundColor: '#4085ee',
  cursor: 'pointer',
});
