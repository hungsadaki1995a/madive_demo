import { Routes, Route, Navigate } from 'react-router-dom';
import MetaManagement from '@/pages/meta/metaManagement/MetaManagement';
import { subMenusType } from '@/types/typeBundle';
import Error from '@/pages/error';

const Meta = ({ subMenus }: { subMenus: subMenusType[] }) => {
  return (
    <Routes>
      <Route
        path="/management"
        element={<MetaManagement title={subMenus[0].title} />}
      />
      <Route
        path="/"
        element={<Navigate to="/development/meta/management" />}
      />
      <Route path="/*" element={<Error />} />
    </Routes>
  );
};

export default Meta;
