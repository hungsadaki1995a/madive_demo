import { TableCell, TableRow } from '@mui/material';
import {
  userSelectionType,
  metaSelectionType,
  nodesSelectionType,
} from '@/types/typeBundle';

interface propsType {
  data: userSelectionType[] | metaSelectionType[] | nodesSelectionType[];
  columns: { [key: string]: string }[];
}

const TableBodyContents = ({ data, columns }: propsType) => {
  return (
    <>
      {data.map((d, idx) => {
        return (
          <TableRow key={`table-body-contents-${idx}`}>
            {columns.map((column, jdx) => {
              console.log(`column >> ${JSON.stringify(column)}`);
              return (
                <TableCell key={`table-body-contents-${idx}-${jdx}`}>
                  {
                    (d as unknown as { [key: string]: string | JSX.Element })[
                      column.field
                    ]
                  }
                </TableCell>
              );
            })}
          </TableRow>
        );
      })}
    </>
  );
};

export default TableBodyContents;
