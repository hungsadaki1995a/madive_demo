import { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { Button } from '@mui/material';
import LogoutIcon from '@mui/icons-material/Logout';
import HorizontalBarDialog from './HorizontalBarDialog';

import makeStyles from '@mui/styles/makeStyles';

const useStyles = makeStyles(() => ({
  wrap: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    width: 'calc(100vw - 240px)',
    minWidth: 1000,
    backgroundColor: '#5F6571',
  },
  menu: {
    display: 'flex',
    justifyContent: 'center',
    borderRight: '1px solid rgba(255, 255, 255, 0.2)',
    borderRadius: 0,
    padding: 16,
    width: 155,
    backgroundColor: 'transparent',
    fontSize: 12,
    color: 'rgb(185, 191, 199)',
    cursor: 'pointer',
  },
  logoutIcon: {
    marginRight: 25,
    color: 'rgb(185, 191, 199)',
    cursor: 'pointer',
  },
}));

interface typesType {
  title: string;
  to: string;
}

interface propsType {
  types: typesType[];
  isLoggedIn: boolean;
}

const HorizontalBar = ({ types }: propsType) => {
  const [openDialog, setOpenDialog] = useState<boolean>(false);
  const classes = useStyles();

  const handleLogout = () => {
    setOpenDialog(true);
  };

  return (
    <div className={classes.wrap}>
      <div>
        {types.map((type, idx) => {
          return (
            <Button
              key={`horizontal-bar-${idx}`}
              className={classes.menu}
              component={NavLink}
              to={type.to}
            >
              {type.title}
            </Button>
          );
        })}
      </div>
      <LogoutIcon className={classes.logoutIcon} onClick={handleLogout} />
      <HorizontalBarDialog
        openDialog={openDialog}
        setOpenDialog={setOpenDialog}
      />
    </div>
  );
};

export default HorizontalBar;
