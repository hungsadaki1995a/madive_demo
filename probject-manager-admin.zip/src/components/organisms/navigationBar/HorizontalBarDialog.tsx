import { Dispatch, SetStateAction } from 'react';
import { useNavigate } from 'react-router';
import {
  Dialog,
  DialogTitle,
  Divider,
  DialogContent,
  DialogActions,
  Button,
} from '@mui/material';
import makeStyles from '@mui/styles/makeStyles';
import { useStore } from '@/utils';

const useStyles = makeStyles(() => ({
  dialog: {
    '& .MuiDialog-container': {
      minWidth: 695,
    },
  },
  dialogTitle: {
    '& h2': {
      fontSize: 16,
      fontWeight: 600,
      color: '#444',
    },
  },
  divider: {
    margin: '0px 20px',
  },
  dialogContent: {
    overflowX: 'hidden',
    '& p': {
      display: 'flex',
      alignItems: 'center',
      width: 175,
      fontSize: 14,
      margin: 0,
    },
    '& input': {
      padding: '5px 10px',
      width: 312,
      fontSize: 14,
      color: '#555',
    },
    '& input[type=radio]': {
      width: 'fit-content',
    },
    '& .Mui-disabled[type=text]': {
      backgroundColor: 'rgba(0, 0, 0, 0.1)',
    },
    '& .Mui-disabled[role=button]': {
      backgroundColor: 'rgba(0, 0, 0, 0.1)',
    },
  },
  dialogDelete: {
    padding: '60px 80px',
  },
}));

interface propsType {
  openDialog: boolean;
  setOpenDialog: Dispatch<SetStateAction<boolean>>;
}

const HorizontalBarDialog = ({ openDialog, setOpenDialog }: propsType) => {
  const classes = useStyles();
  const { AuthStore } = useStore();
  const navigate = useNavigate();

  const handleSubmitDialog = () => {
    window.sessionStorage.clear();
    AuthStore.initializeAuth();
    navigate('/login');
    handleCloseDialog();
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
  };

  return (
    <Dialog
      className={classes.dialog}
      maxWidth="md"
      open={openDialog}
      onClose={handleCloseDialog}
      aria-labelledby="form-dialog-title"
    >
      <DialogTitle className={classes.dialogTitle} id="form-dialog-title">
        Log out
      </DialogTitle>
      <Divider className={classes.divider} />
      <DialogContent className={classes.dialogDelete}>
        Are you sure to log out?
      </DialogContent>
      <DialogActions>
        <Button
          onClick={handleSubmitDialog}
          color="primary"
          variant="contained"
        >
          OK
        </Button>
        <Button onClick={handleCloseDialog} color="inherit" variant="contained">
          Cancel
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default HorizontalBarDialog;
