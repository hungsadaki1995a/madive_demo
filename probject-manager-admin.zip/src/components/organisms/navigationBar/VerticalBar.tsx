import React, { useState, useEffect, Dispatch, SetStateAction } from 'react';
import { useNavigate } from 'react-router';
import { NavLink, useLocation } from 'react-router-dom';
import { ListItem, Collapse, Button } from '@mui/material';
import makeStyles from '@mui/styles/makeStyles';
import { menusType } from '@/types/typeBundle';
import logo from '@/images/main/proobject_logo.png';

const useStyles = makeStyles(() => ({
  wrap: {
    display: 'flex',
    flexDirection: 'column',
    width: 240,
    height: '100vh',
    '& li': {
      padding: 0,
    },
  },
  title: {
    padding: 15,
    width: 210,
    height: 23,
    backgroundColor: '#5E82E0',
  },
  icon: {
    borderRadius: '50%',
    padding: 3,
    backgroundColor: '#fff',
  },
  iconSelected: {
    color: '#3f51b5',
  },
  list: {
    display: 'flex',
    flexDirection: 'column',
  },
  collapse: {
    width: '100%',
  },
  button: {
    borderRadius: 0,
    padding: 7.5,
    width: '100%',
  },
  buttonTitle: {
    display: 'flex',
    justifyContent: 'flex-start',
    marginLeft: 10,
    flexGrow: 1,
    color: '#000',
  },
  buttonActive: {
    backgroundColor: 'rgba(0, 0, 0, 0.1)',
  },
  buttonDisabled: {
    backgroundColor: '#fff',
  },
  subButton: {
    display: 'flex',
    justifyContent: 'flex-start',
    backgroundColor: 'rgba(0, 0, 0, 0.1)',
    borderRadius: 0,
    padding: 7.5,
    width: '100%',
  },
  subButtonTitle: {
    marginLeft: 40,
    color: '#000',
  },
}));

const VerticalSubItem = ({ title, to }: { title: string; to: string }) => {
  const classes = useStyles();

  return (
    <ListItem>
      <Button className={classes.subButton} component={NavLink} to={to}>
        <span className={classes.subButtonTitle}>{title}</span>
      </Button>
    </ListItem>
  );
};

interface itemsType {
  menu: menusType;
  Icon: any;
  opened: { [key: string]: boolean };
  setOpened: Dispatch<SetStateAction<{ [key: string]: boolean }>>;
}

interface propsType {
  menus: menusType[];
  isLoggedIn: boolean;
}

const VerticalItem = ({ menu, Icon, opened, setOpened }: itemsType) => {
  const classes = useStyles();

  const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    const name: string | null = (e.target as HTMLElement).textContent;
    if (!name) return;
    const newBar = { User: false, Meta: false, Node: false, Prominer: false };
    setOpened({ ...newBar, [name]: !opened[name] });
  };

  return (
    <ListItem className={classes.list}>
      <Button
        className={`${classes.button} ${
          opened[menu.title] ? classes.buttonActive : classes.buttonDisabled
        }`}
        onClick={handleClick}
      >
        <Icon
          className={`${classes.icon} ${
            opened[menu.title] ? classes.iconSelected : ''
          }`}
        />
        <span className={classes.buttonTitle}>{menu.title}</span>
      </Button>
      <Collapse
        className={classes.collapse}
        in={opened[menu.title]}
        unmountOnExit
      >
        <ul>
          {menu.subMenus.map((subMenu, jdx) => {
            return (
              <VerticalSubItem
                key={`main-menu-subitem-${jdx}`}
                title={subMenu.title}
                to={subMenu.to}
              />
            );
          })}
        </ul>
      </Collapse>
    </ListItem>
  );
};

const VerticalBar = ({ menus }: propsType) => {
  const tabName = useLocation().pathname.split('/');
  const [opened, setOpened] = useState<{ [key: string]: boolean }>({
    User: !tabName || tabName.includes('user'),
    Meta: tabName.includes('meta'),
    Node: tabName.includes('node'),
    Prominer: tabName.includes('prominer'),
  });
  const navigate = useNavigate();
  const location = useLocation();
  const classes = useStyles();

  useEffect(() => {
    if (!window.sessionStorage.getItem('session')) {
      // navigate('/login');  // re-render bug fix
    }
    setOpened({
      User: !tabName || tabName.includes('user'),
      Meta: tabName.includes('meta'),
      Node: tabName.includes('node'),
      Prominer: tabName.includes('prominer'),
    });
    // eslint-disable-next-line
  }, [navigate, location.pathname]);

  return (
    <div className={classes.wrap}>
      <img className={classes.title} src={logo} alt="vertical-bar-logo"></img>
      <ul>
        {menus.map((menu, idx) => {
          return (
            <VerticalItem
              key={`main-menu-item-${idx}`}
              menu={menu}
              Icon={menu.icon}
              opened={opened}
              setOpened={setOpened}
            />
          );
        })}
      </ul>
    </div>
  );
};

export default VerticalBar;
