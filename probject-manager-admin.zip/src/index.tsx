import React from 'react';
import ReactDOM from 'react-dom/client';
import { Theme, StyledEngineProvider } from '@mui/material';
import App from './App';
import { worker } from '@/mocks/browsers';
import './stylesheets/index.css';

const { NODE_ENV } = process.env as {
  [key: string]: string;
};

if (NODE_ENV === 'development') {
  worker.start();
}

declare module '@mui/styles/defaultTheme' {
  // eslint-disable-next-line @typescript-eslint/no-empty-interface
  interface DefaultTheme extends Theme {}
}

const wrap = ReactDOM.createRoot(
  document.getElementById('wrap') as HTMLElement
);

wrap.render(
  <React.StrictMode>
    <StyledEngineProvider injectFirst>
      <App />
    </StyledEngineProvider>
  </React.StrictMode>
);
