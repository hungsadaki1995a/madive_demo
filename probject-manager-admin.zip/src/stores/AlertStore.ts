import { makeAutoObservable } from 'mobx';
import { apiAlertType } from '@/types/typeBundle';

class AlertStore {
  open = false;

  options: apiAlertType = {
    severity: null,
    message: null,
  };

  constructor() {
    makeAutoObservable(this);
  }

  openApiAlert = (severity: 'success' | 'error', message: string) => {
    this.open = true;
    this.options = {
      severity: severity,
      message: message,
    };
  };

  resetApiAlert = () => {
    this.open = false;
    this.options = {
      severity: null,
      message: null,
    };
  };
}

export default new AlertStore();
