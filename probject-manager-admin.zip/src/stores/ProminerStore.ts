import { makeAutoObservable } from 'mobx';
import {
  dependencyResponseType,
  resourceResponseType,
  dependencySettingsType,
} from '@/types/typeBundle';

class ProminerStore {
  dependencyValue: dependencyResponseType = {
    createdAt: '',
    id: -1,
    projects: [{ id: -1, name: '' }],
    repository: {
      branchName: '',
      lastCommitId: '',
      name: '',
      platform: { type: '', url: '' },
      token: '',
      url: '',
    },
  };

  resourceValue: resourceResponseType[] = [];

  dependencyDirection = 'FORWARD';

  dependencySettings: dependencySettingsType = {
    project: '',
    type: 'ALL',
    direction: 'Forward',
    name: '',
  };

  constructor() {
    makeAutoObservable(this);
  }

  setDependency = (dependencyInfo: dependencyResponseType) => {
    this.dependencyValue = dependencyInfo;
  };

  setResources = (resourceInfo: resourceResponseType[]) => {
    this.resourceValue = resourceInfo;
  };

  setDependencySettings = (settingsInfo: dependencySettingsType) => {
    this.dependencySettings = settingsInfo;
  };

  setResourceValue = (resourceValue: resourceResponseType[]) => {
    this.resourceValue = resourceValue;
  };

  setDependencyDirection = (dir: 'FORWARD' | 'BACKWARD') => {
    this.dependencyDirection = dir;
  };
}

export default new ProminerStore();
