import { makeAutoObservable } from 'mobx';
import { metaType, metaSelectionType } from '@/types/typeBundle';

class MetaStore {
  meta: metaType[] = [];
  selectedMeta: string[] = [];
  order: 'asc' | 'desc' = 'asc';
  orderProperty: keyof metaSelectionType = 'physicalName';

  constructor() {
    makeAutoObservable(this);
  }

  setMeta = (meta: metaType[]) => {
    this.meta = [...meta];
  };

  setSelectedMeta = (selectedData: string[]) => {
    this.selectedMeta = selectedData;
  };

  setOrder = (order: 'asc' | 'desc') => {
    this.order = order;
  };

  setOrderProperty = (property: keyof metaSelectionType) => {
    this.orderProperty = property;
  };
}

export default new MetaStore();
