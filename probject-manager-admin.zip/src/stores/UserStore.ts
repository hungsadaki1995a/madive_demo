import { makeAutoObservable } from 'mobx';
import { userType } from '@/types/typeBundle';

class UserStore {
  userInfo: userType[] = [];
  selectedUsers: string[] = [];
  order: 'asc' | 'desc' = 'asc';
  orderProperty: keyof userType = 'userId';
  searchText = '';
  searchType = 'User ID';

  constructor() {
    makeAutoObservable(this);
  }

  setUsers = (userInfo: userType[]) => {
    this.userInfo = userInfo;
  };

  getUserPassword = (userId: string) => {
    const targetUser = this.userInfo.find((user: userType) => {
      return user.userId === userId;
    });
    return targetUser ? targetUser.userPasswd : null;
  };

  setSelectedUsers = (selectedData: string[]) => {
    this.selectedUsers = selectedData;
  };

  setOrder = (order: 'asc' | 'desc') => {
    this.order = order;
  };

  setOrderProperty = (property: keyof userType) => {
    this.orderProperty = property;
  };

  setSearchText = (text: string) => {
    this.searchText = text;
  };

  setSearchType = (type: string) => {
    this.searchType = type;
  };
}

export default new UserStore();
