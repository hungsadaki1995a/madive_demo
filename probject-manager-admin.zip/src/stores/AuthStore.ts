import { makeAutoObservable } from 'mobx';
import { userType } from '@/types/typeBundle';

class AuthStore {
  userInfo = {
    email: '',
    userId: '',
    userPasswd: '',
    userName: '',
    userDiv: '',
    telNo: '',
  };

  constructor() {
    makeAutoObservable(this);
  }

  initializeAuth = () => {
    this.userInfo = {
      email: '',
      userId: '',
      userPasswd: '',
      userName: '',
      userDiv: '',
      telNo: '',
    };
  };

  setUser = (userInfo: userType) => {
    this.userInfo = userInfo;
  };
}

export default new AuthStore();
