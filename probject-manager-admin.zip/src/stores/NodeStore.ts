import { makeAutoObservable } from 'mobx';
import { nodesType } from '@/types/typeBundle';

class NodeStore {
  nodes: nodesType[] = [];
  masterNodes: nodesType[] = [];
  selectedNodes: string[] = [];
  order: 'asc' | 'desc' = 'asc';
  orderProperty: keyof nodesType = 'nodeName';
  searchText = '';
  searchType = 'Node Name';

  constructor() {
    makeAutoObservable(this);
  }

  setNodes = (nodes: nodesType[]) => {
    this.nodes = [...nodes];
    this.masterNodes = nodes.filter((node) => {
      return node.nodeType === 'MASTER';
    });
  };

  setSelectedNodes = (selectedData: string[]) => {
    this.selectedNodes = selectedData;
  };

  setOrder = (order: 'asc' | 'desc') => {
    this.order = order;
  };

  setOrderProperty = (property: keyof nodesType) => {
    this.orderProperty = property;
  };

  setSearchText = (text: string) => {
    this.searchText = text;
  };

  setSearchType = (type: string) => {
    this.searchType = type;
  };
}

export default new NodeStore();
